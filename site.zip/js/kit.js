/* Общий набор для сборки «как в Figma, вместе»: несколько виртуальных курсоров собирают настоящие
   элементы страницы. Им пользуются сборка первого экрана (js/intro.js) и сборка блоков при прокрутке (js/scenes.js).

   Сцена (stage) — одна временная шкала в миллисекундах от её старта. Пока сцена описывается, ничего
   не двигается: шаги только записываются, поэтому размеры элементов меряются по чистой раскладке.
   commit() превращает записанное в анимации Web Animations API, cancel() снимает их, убирает временные
   слои и возвращает разметку и стили: после любой сцены страница в обычном готовом виде.

   У курсора роль, от неё цвет стрелки, рамок и каретки:
     move — перенос и расстановка,   size  — размер и выравнивание,
     text — набор и правка текста,   media — картинки и кнопки.
   Курсор, который держит элемент, идёт по тем же ключам и с той же кривой, что и сам элемент,
   поэтому точка захвата не отстаёт. Случайных величин нет: сцена повторяется кадр в кадр.

   Движение элементов — отдельные свойства translate, rotate, scale и clip-path. Свойство transform,
   на котором держатся наклон карточек и параллакс первого экрана, сцены не трогают. */
(() => {
  'use strict';

  const EASE = 'cubic-bezier(.22,.61,.36,1)';     // появление
  const MOVE = 'cubic-bezier(.45,.05,.25,1)';     // перелёт курсора
  const DRAG = 'cubic-bezier(.3,.66,.22,1)';      // перенос: быстрый старт, мягкая посадка
  const SNAP = 'cubic-bezier(.45,0,.25,1)';       // доводка и возврат после перелёта

  // Инструменты разработки работают только на своём компьютере
  const host = location.hostname;
  const dev = location.protocol === 'file:' || ['localhost', '127.0.0.1', '[::1]'].includes(host) || /\.(localhost|test)$/.test(host);
  const slowM = dev && /[?&]slow=(\d+(?:\.\d+)?)/.exec(location.search);
  const slow = slowM ? Math.min(20, Math.max(.1, +slowM[1])) : 1;
  const stepMode = dev && /[?&]step=1(&|$)/.test(location.search);

  const ok = !!(document.body && document.body.animate && window.CSS && CSS.supports &&
    CSS.supports('translate', '1px 1px') && CSS.supports('clip-path', 'inset(0px round 2px)'));

  const px = v => v.toFixed(1) + 'px';
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const esc = ch => ch === '&' ? '&amp;' : ch === '<' ? '&lt;' : ch === '>' ? '&gt;' : ch;
  const isSpace = ch => ch === ' ' || ch === ' ';

  const ARROW = '<svg class="kc__arrow" viewBox="0 0 22 22"><path d="M3 2v16l4.5-4.2 3.1 6.6 2.8-1.2-3-6.5 6.2-.1z"/></svg>';
  const BEAM_PATH = 'M7 3.5h2.4c.9 0 1.6.5 1.6 1.3 0-.8.7-1.3 1.6-1.3H15M11 4.8v12.4M7 18.5h2.4c.9 0 1.6-.5 1.6-1.3 0 .8.7 1.3 1.6 1.3H15';
  const BEAM = '<svg class="intro-beam" viewBox="0 0 22 22">' +
    `<path d="${BEAM_PATH}" fill="none" stroke="#0A0A0B" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>` +
    `<path d="${BEAM_PATH}" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  /* ---------- Курсор ---------- */

  // Курсор, которому не хватило места в общем лимите: все команды пропускаются, действия идут без него
  const GHOST = { real: false, role: null, t: 0, p: null };
  ['enter', 'go', 'seg', 'press', 'beam', 'exit'].forEach(m => { GHOST[m] = () => GHOST; });
  GHOST.compile = () => 0;

  function makeCursor(s, role) {
    const el = document.createElement('div');
    el.className = 'intro-cursor kc k-' + role;
    el.innerHTML = ARROW + BEAM;
    s.layer.append(el);
    const arrow = el.firstChild, beam = el.lastChild;
    const pts = [], presses = [], beams = [];     // точки пути { t, x, y, o — непрозрачность, e — кривая до следующей }
    const last = () => pts[pts.length - 1];
    const push = (t, p, o) => {
      const l = last();
      if (l && t < l.t) { if (dev) console.warn('Kit: курсор опаздывает', role, Math.round(t), Math.round(l.t)); t = l.t; }
      pts.push({ t, x: p.x, y: p.y, o, e: 'linear' });
    };
    // До момента t курсор стоит, дальше движется с кривой e
    const hold = (t, e) => {
      const l = last();
      if (l.t < t) pts.push({ t, x: l.x, y: l.y, o: l.o, e }); else l.e = e;
    };
    const c = {
      real: true, role,
      get t() { const l = last(); return l ? l.t : 0; },
      get p() { const l = last(); return l ? { x: l.x, y: l.y } : null; },
      // Появляется рядом с точкой p и к моменту t подлетает к ней
      enter(t, p, off = { x: 34, y: 26 }, dur = 240) {
        push(Math.max(0, t - dur), { x: p.x + off.x, y: p.y + off.y }, 0);
        last().e = MOVE;
        push(t, p, 1);
        return c;
      },
      // К моменту t перелетает в точку p; курсора ещё нет — появляется
      go(t, p, dur) {
        const l = last();
        if (!l) return c.enter(t, p);
        const d = dur || clamp(Math.hypot(p.x - l.x, p.y - l.y) * .9, 160, 420);
        const t0 = Math.max(l.t, t - d);
        hold(t0, MOVE);
        push(Math.max(t, t0 + 60), p, 1);
        return c;
      },
      // Точный отрезок переноса: те же время и кривая, что у элемента в руке
      seg(t0, t1, p, e) { hold(t0, e); push(t1, p, 1); return c; },
      press(t0, t1) { presses.push([t0, t1]); return c; },
      beam(t0, t1) { beams.push([t0, t1]); return c; },
      // Уходит: отлетает в сторону и гаснет
      exit(t, off = { x: 40, y: 32 }, dur = 300) {
        const l = last();
        if (!l) return c;
        hold(Math.max(l.t, t), EASE);
        push(last().t + dur, { x: l.x + off.x, y: l.y + off.y }, 0);
        return c;
      },
      compile() {
        if (pts.length < 2) { el.remove(); return 0; }
        const end = last().t;
        const tr = p => `translate3d(${px(p.x - 3)},${px(p.y - 2)},0)`;
        const kf = [];
        if (pts[0].t > 0) kf.push({ offset: 0, transform: tr(pts[0]), opacity: 0, easing: 'linear' });
        pts.forEach(p => kf.push({ offset: p.t / end, transform: tr(p), opacity: p.o, easing: p.e }));
        s.add(el, kf, { delay: 0, duration: end, easing: 'linear' });
        // Нажатие: стрелка чуть сжимается, пока элемент в руке
        presses.forEach(([t0, t1]) => {
          const d = Math.max(t1 - t0, 120), a = Math.min(.4, 70 / d);
          s.add(arrow, [{ transform: 'scale(1)' }, { transform: 'scale(.84)', offset: a }, { transform: 'scale(.84)', offset: 1 - a }, { transform: 'scale(1)' }],
            { delay: Math.max(0, t0), duration: d, easing: 'linear', fill: 'none' });
        });
        // Набор текста: стрелка становится «балкой»
        beams.forEach(([t0, t1]) => {
          const o = { delay: Math.max(0, t0), duration: Math.max(1, t1 - t0), easing: 'linear', fill: 'none' };
          s.add(arrow, [{ opacity: 0 }, { opacity: 0 }], o);
          s.add(beam, [{ opacity: 1 }, { opacity: 1 }], o);
        });
        return end;
      }
    };
    return c;
  }

  /* ---------- Сцена ---------- */

  const live = new Set();

  function stage(hostEl, { tempo = 1, cursors = 4 } = {}) {
    const layer = document.createElement('div');
    layer.className = 'intro-layer';
    layer.setAttribute('aria-hidden', 'true');
    hostEl.append(layer);
    const HR = hostEl.getBoundingClientRect();
    const specs = [], anims = [], undo = [], crs = [];
    let left = cursors, end = 0, cursorEnd = 0, over = false;

    const s = {
      layer, tempo, hostRect: HR,
      get end() { return end; },
      get cursorEnd() { return cursorEnd; },
      // Координаты элемента относительно слоя сцены
      rel(el) { const r = el.getBoundingClientRect(); return { x: r.left - HR.left, y: r.top - HR.top, w: r.width, h: r.height }; },
      add(el, kf, o) { specs.push([el, kf, o]); end = Math.max(end, (o.delay || 0) + o.duration); },
      // Временный инлайн-стиль: при снятии сцены вернётся прежний
      style(el, props) {
        const prev = {};
        Object.keys(props).forEach(k => { prev[k] = el.style[k]; });
        Object.assign(el.style, props);
        undo.push(() => Object.assign(el.style, prev));
      },
      onCancel(f) { undo.push(f); },
      cursor(role) {
        if (left <= 0) return GHOST;
        left--;
        const c = makeCursor(s, role);
        crs.push(c);
        return c;
      },
      commit() {
        crs.forEach(c => { cursorEnd = Math.max(cursorEnd, c.compile()); });
        specs.forEach(([el, kf, o]) => {
          anims.push(el.animate(kf, { fill: 'both', easing: EASE, ...o, delay: (o.delay || 0) * tempo, duration: Math.max(1, o.duration * tempo) }));
        });
        live.add(s);
        return end * tempo;
      },
      seek(ms) { anims.forEach(a => { a.pause(); a.currentTime = ms * tempo; }); },
      jump(ms) { anims.forEach(a => { a.currentTime = ms * tempo; }); },      // перейти к моменту сцены и играть дальше
      step(ms) { anims.forEach(a => { a.pause(); a.currentTime = Math.max(0, (a.currentTime || 0) + ms * tempo); }); },
      cancel() {
        if (over) return;
        over = true;
        live.delete(s);
        anims.forEach(a => { try { a.cancel(); } catch (e) { /* уже снята */ } });
        undo.reverse().forEach(f => { try { f(); } catch (e) { /* элемент уже убран со страницы */ } });
        layer.remove();
      }
    };
    s.frame = (box, role, o) => frame(s, box, role, o);
    s.drag = (el, o) => drag(s, el, o);
    s.crop = (el, o) => crop(s, el, o);
    s.marquee = (box, o) => marquee(s, box, o);
    s.select = (target, t0, t1, role, o) => select(s, target, t0, t1, role, o);
    s.guide = (line, t0, t1, role) => guide(s, line, t0, t1, role);
    s.tint = (keys, role, t0, t1) => tint(s, keys, role, t0, t1);
    s.show = (el, t, o) => show(s, el, t, o);
    s.pop = (el, t, o) => pop(s, el, t, o);
    s.setupType = (el, parts, o) => setupType(s, el, parts, o);
    s.type = (el, parts, o) => { const tp = setupType(s, el, parts, o); return tp.run(o); };
    s.lines = (el, o) => lines(s, el, o);
    s.lineBoxes = el => lineBoxes(s, el);
    return s;
  }

  /* ---------- Действия ---------- */

  // Временная рамка выделения: цвет по роли, восемь маркеров
  function frame(s, box, role, { handles = true, cls = '' } = {}) {
    const f = document.createElement('div');
    f.className = 'intro-frame k-' + role + (cls ? ' ' + cls : '');
    if (handles) f.innerHTML = '<i></i>'.repeat(8);
    Object.assign(f.style, { left: px(box.x), top: px(box.y), width: px(box.w), height: px(box.h) });
    s.layer.append(f);
    return f;
  }

  // Видимость временного слоя: появился к t0, держится до t1, гаснет
  function vis(s, el, t0, t1, a = 80, b = 160) {
    const T0 = Math.max(0, t0 - a), T1 = Math.max(t1, T0 + 1) + b, D = T1 - T0;
    s.add(el, [{ opacity: 0 }, { opacity: 1, offset: (t0 - T0) / D }, { opacity: 1, offset: Math.max(t1 - T0, t0 - T0) / D }, { opacity: 0 }],
      { delay: T0, duration: D, easing: 'linear' });
  }

  // Элемент скрыт до t, затем быстро проявляется (так он «берётся в руку»)
  const appear = (s, el, t, d = 120) => s.add(el, [{ opacity: 0 }, { opacity: 1 }], { delay: Math.max(0, t), duration: d, easing: 'linear' });

  /* Перенос. Элемент держат за точку grab (доли рамки box) и ведут по ключам.
     moves — один или несколько захватов подряд: у каждого свой курсор и своя точка захвата.
     Ключ: [время, поза, кривая до следующего ключа]; поза { x, y, r, s } — сдвиг, поворот в градусах и масштаб
     относительно готового места. Последний ключ — готовое место ({}).
     origin — точка поворота и масштаба (доли box); box по умолчанию — рамка самого элемента. */
  function drag(s, el, { moves, c, grab, keys, box, origin = [.5, .5], frame: role = null, pad = 6, appear: ap = true, linger = 200 }) {
    if (!moves) moves = [{ c, grab, keys }];
    const E = s.rel(el), B = box || E;
    const O = { x: B.x + B.w * origin[0], y: B.y + B.h * origin[1] };
    s.style(el, { transformOrigin: `${px(O.x - E.x)} ${px(O.y - E.y)}` });
    const all = [].concat(...moves.map(m => m.keys));
    const t0 = all[0][0], tN = all[all.length - 1][0], D = Math.max(1, tN - t0);
    const pose = k => ({ x: 0, y: 0, r: 0, s: 1, ...k[1] });
    const hasR = all.some(k => k[1].r), hasS = all.some(k => k[1].s != null && k[1].s !== 1);
    const kf = all.map(k => {
      const p = pose(k);
      const f = { offset: (k[0] - t0) / D, translate: `${px(p.x)} ${px(p.y)}`, easing: k[2] || SNAP };
      if (hasR) f.rotate = p.r + 'deg';
      if (hasS) f.scale = String(p.s);
      return f;
    });
    s.add(el, kf, { delay: t0, duration: D, easing: 'linear' });
    if (ap) appear(s, el, t0 - 60);

    // Где точка захвата g, когда элемент в позе p (сдвиг, поворот и масштаб вокруг O)
    const at = (g, p) => {
      const gx = B.x + B.w * g[0] - O.x, gy = B.y + B.h * g[1] - O.y;
      const a = p.r * Math.PI / 180, cs = Math.cos(a), sn = Math.sin(a);
      return { x: O.x + (gx * cs - gy * sn) * p.s + p.x, y: O.y + (gx * sn + gy * cs) * p.s + p.y };
    };
    let held = false;
    moves.forEach(m => {
      const cc = m.c || GHOST;
      if (!cc.real) return;
      held = true;
      const g = m.grab || [.5, .5], k0 = m.keys[0], kN = m.keys[m.keys.length - 1];
      cc.go(k0[0], at(g, pose(k0)));
      cc.press(k0[0] - 30, kN[0] + 40);
      for (let i = 1; i < m.keys.length; i++) cc.seg(m.keys[i - 1][0], m.keys[i][0], at(g, pose(m.keys[i])), m.keys[i - 1][2] || SNAP);
    });

    // Рамка выделения едет вместе с элементом — только если его кто-то держит
    if (role && held) {
      const F = { x: B.x - pad, y: B.y - pad, w: B.w + pad * 2, h: B.h + pad * 2 };
      const f = frame(s, F, role);
      f.style.transformOrigin = `${px(O.x - F.x)} ${px(O.y - F.y)}`;
      s.add(f, kf.map(x => ({ ...x })), { delay: t0, duration: D, easing: 'linear' });
      vis(s, f, t0 - 30, tN + linger);
    }
    return { box: B, at };
  }

  /* Кадрирование: видимая часть элемента — clip-path; так открывают картинку или тянут контейнер за край.
     Ключ: [время, [сверху, справа, снизу, слева] — доли размера, кривая]. Курсор держит край handle. */
  function crop(s, el, { c, keys, round = '', handle = 'br', frame: role = null, pad = 0, appear: ap = true, linger = 160 }) {
    const B = s.rel(el);
    const ins = v => `inset(${px(v[0] * B.h)} ${px(v[1] * B.w)} ${px(v[2] * B.h)} ${px(v[3] * B.w)}${round ? ' round ' + round : ''})`;
    const t0 = keys[0][0], tN = keys[keys.length - 1][0], D = Math.max(1, tN - t0);
    s.add(el, keys.map(k => ({ offset: (k[0] - t0) / D, clipPath: ins(k[1]), easing: k[2] || DRAG })), { delay: t0, duration: D, easing: 'linear' });
    if (ap) appear(s, el, t0 - 50, 100);
    const rect = v => ({ x: B.x + v[3] * B.w, y: B.y + v[0] * B.h, w: B.w * (1 - v[1] - v[3]), h: B.h * (1 - v[0] - v[2]) });
    const pt = v => {
      const r = rect(v);
      return {
        br: { x: r.x + r.w, y: r.y + r.h }, r: { x: r.x + r.w, y: r.y + r.h / 2 }, tr: { x: r.x + r.w, y: r.y },
        l: { x: r.x, y: r.y + r.h / 2 }, bl: { x: r.x, y: r.y + r.h }, b: { x: r.x + r.w / 2, y: r.y + r.h }
      }[handle];
    };
    const cc = c || GHOST;
    if (cc.real) {
      cc.go(t0, pt(keys[0][1]));
      cc.press(t0 - 30, tN + 40);
      for (let i = 1; i < keys.length; i++) cc.seg(keys[i - 1][0], keys[i][0], pt(keys[i][1]), keys[i - 1][2] || DRAG);
    }
    if (role && cc.real) {
      const f = frame(s, rect(keys[0][1]), role);
      s.add(f, keys.map(k => {
        const r = rect(k[1]);
        return { offset: (k[0] - t0) / D, left: px(r.x - pad), top: px(r.y - pad), width: px(r.w + pad * 2), height: px(r.h + pad * 2), easing: k[2] || DRAG };
      }), { delay: t0, duration: D, easing: 'linear' });
      vis(s, f, t0 - 30, tN + linger);
    }
  }

  /* Рамка, которую курсор тянет из угла: так создаётся текстовое поле или выделение.
     from — начальный размер в долях; over — на сколько px курсор сначала перетягивает правый край;
     fix — [t2, t3]: курсор берёт правый маркер и доводит ширину до места */
  function marquee(s, box, { c, role, t0, t1, from = [.05, .1], over = 0, fix = null, until, handles = true, fill = false }) {
    const f = frame(s, box, role, { handles, cls: fill ? 'intro-frame--fill' : '' });
    const w0 = box.w * from[0], h0 = box.h * from[1];
    const tEnd = fix ? fix[1] : t1, D = Math.max(1, tEnd - t0);
    const kf = [{ offset: 0, width: px(w0), height: px(h0), easing: DRAG }];
    if (fix) {
      kf.push({ offset: (t1 - t0) / D, width: px(box.w + over), height: px(box.h), easing: 'linear' },
        { offset: (fix[0] - t0) / D, width: px(box.w + over), height: px(box.h), easing: SNAP });
    }
    kf.push({ offset: 1, width: px(box.w), height: px(box.h) });
    if (!fix && over) kf[kf.length - 1].width = px(box.w + over);
    s.add(f, kf, { delay: t0, duration: D, easing: 'linear' });
    vis(s, f, t0 - 20, until != null ? until : tEnd + 260, 60);
    const cc = c || GHOST;
    if (cc.real) {
      cc.go(t0, { x: box.x + w0, y: box.y + h0 });
      cc.press(t0 - 20, t1 + 30);
      cc.seg(t0, t1, { x: box.x + box.w + over, y: box.y + box.h }, DRAG);
      if (fix) {
        cc.go(fix[0], { x: box.x + box.w + over, y: box.y + box.h / 2 }, 160);
        cc.press(fix[0] - 30, fix[1] + 30);
        cc.seg(fix[0], fix[1], { x: box.x + box.w, y: box.y + box.h / 2 }, SNAP);
      }
    }
    return f;
  }

  // Неподвижная рамка выделения вокруг элемента или прямоугольника
  function select(s, target, t0, t1, role, { pad = 6, handles = true } = {}) {
    const B = target.nodeType ? s.rel(target) : target;
    const f = frame(s, { x: B.x - pad, y: B.y - pad, w: B.w + pad * 2, h: B.h + pad * 2 }, role, { handles });
    vis(s, f, t0, t1, 60, 140);
    return f;
  }

  // Направляющая: пунктирная линия, к которой элемент «прилипает». w = 0 — вертикальная
  function guide(s, line, t0, t1, role) {
    const g = document.createElement('div');
    g.className = 'k-guide k-' + role + (line.w ? ' k-guide--h' : '');
    Object.assign(g.style, { left: px(line.x), top: px(line.y), width: px(line.w || 0), height: px(line.h || 0) });
    s.layer.append(g);
    vis(s, g, t0, t1, 60, 180);
  }

  // Подсветка отступа: заштрихованная полоса, которая меняется вместе с элементом
  function tint(s, keys, role, t0, t1) {
    const f = document.createElement('div');
    f.className = 'k-tint k-' + role;
    const b0 = keys[0][1];
    Object.assign(f.style, { left: px(b0.x), top: px(b0.y), width: px(b0.w), height: px(b0.h) });
    s.layer.append(f);
    const a = keys[0][0], D = Math.max(1, keys[keys.length - 1][0] - a);
    s.add(f, keys.map(k => ({ offset: (k[0] - a) / D, left: px(k[1].x), top: px(k[1].y), width: px(k[1].w), height: px(k[1].h), easing: k[2] || SNAP })),
      { delay: a, duration: D, easing: 'linear' });
    vis(s, f, t0, t1);
  }

  // Простое появление со сдвигом или масштабом
  function show(s, el, t, { dur = 200, x = 0, y = 0, sc = 1, e = EASE } = {}) {
    const a = { opacity: 0 }, b = { opacity: 1 };
    if (x || y) { a.translate = `${px(x)} ${px(y)}`; b.translate = '0px 0px'; }
    if (sc !== 1) { a.scale = String(sc); b.scale = '1'; }
    s.add(el, [a, b], { delay: Math.max(0, t), duration: dur, easing: e });
  }

  // Появление с лёгким перелётом по размеру: так ставят кнопку или маленькую картинку
  function pop(s, el, t, { from = .82, dur = 340, origin } = {}) {
    if (origin) s.style(el, { transformOrigin: origin });
    s.add(el, [
      { opacity: 0, scale: String(from), easing: DRAG },
      { opacity: 1, scale: '1.035', offset: .58, easing: SNAP },
      { opacity: 1, scale: '1' }
    ], { delay: Math.max(0, t), duration: dur, easing: 'linear' });
  }

  /* ---------- Текст ---------- */

  // Набор идёт очередями по 1–4 знака, как у человека; узор фиксированный
  const BURST = [2, 3, 1, 3, 2, 4, 1, 2, 3];

  /* Набор инструментом «Текст». setupType сразу делит текст на знаки и меряет их, run() записывает набор:
     знаки появляются очередями, рамка текстового поля растёт вслед за текстом, за последним знаком идёт
     каретка, в конце поле на мгновение выделяется. parts — селектор кусков текста внутри el (null — весь el).
     Разметка вернётся при снятии сцены. */
  function setupType(s, el, parts, { pad = 6, role = 'text', minW = 0 } = {}) {
    const pieces = parts ? [...el.querySelectorAll(parts)] : [el];
    const saved = pieces.map(p => p.innerHTML);
    const label = el.getAttribute('aria-label');
    if (label == null) el.setAttribute('aria-label', el.textContent.replace(/\s+/g, ' ').trim());
    pieces.forEach(p => { p.innerHTML = [...p.textContent].map(ch => `<span class="type-ch">${esc(ch)}</span>`).join(''); });
    s.onCancel(() => {
      pieces.forEach((p, i) => { p.innerHTML = saved[i]; });
      if (label == null) el.removeAttribute('aria-label');
    });
    const chars = [...el.querySelectorAll('.type-ch')];
    if (!chars.length) return { box0: null, at: null, run: o => ({ at: null, end: o.t0 }) };

    const R = chars.map(x => s.rel(x));
    const x0 = R[0].x - pad, y0 = Math.min(...R.map(r => r.y)) - pad;
    const box0 = { x: x0, y: y0, w: Math.max(minW, pad * 2 + 2), h: R[0].h + pad * 2 };
    const at = { x: R[0].x + 1, y: R[0].y + R[0].h / 2 };

    const groups = [];
    let g = [], n = 0;
    chars.forEach((ch, i) => {
      g.push(i);
      const sp = isSpace(ch.textContent);
      if (sp || g.length >= BURST[n % BURST.length]) { groups.push({ idx: g, sp }); g = []; n++; }
    });
    if (g.length) groups.push({ idx: g, sp: false });

    function run({ c, t0, t1 }) {
      // Время каждой очереди: пробел — короткая пауза, длинная очередь чуть дольше
      const weights = groups.map(gr => .8 + gr.idx.length * .22 + (gr.sp ? .55 : 0));
      const per = (t1 - t0) / weights.reduce((a, b) => a + b, 0);
      let t = t0;
      const times = weights.map(w => { const v = t; t += w * per; return v; });
      groups.forEach((gr, j) => gr.idx.forEach((i, q) => s.add(chars[i], [{ opacity: 0 }, { opacity: 1 }], { delay: times[j] + q * 12, duration: 16, easing: 'linear' })));

      // Где каретка и какого размера поле после каждой очереди
      let right = R[0].x, bottom = R[0].y + R[0].h;
      const steps = groups.map(gr => {
        gr.idx.forEach(i => { right = Math.max(right, R[i].x + R[i].w); bottom = Math.max(bottom, R[i].y + R[i].h); });
        const r = R[gr.idx[gr.idx.length - 1]];
        return { cx: r.x + r.w, cy: r.y, ch: r.h, w: Math.max(minW, right - x0 + pad), h: bottom - y0 + pad };
      });
      const first = { cx: R[0].x, cy: R[0].y, ch: R[0].h, w: box0.w, h: box0.h };
      const tSel = t1 + 90, tEnd = t1 + 300, span = tEnd - t0;
      const off = ms => clamp((ms - t0) / span, 0, 1);
      // Ступенчатые кадры: состояние меняется скачком в момент очереди
      const track = state => {
        const kf = [{ offset: 0, ...state(first) }];
        steps.forEach((st, i) => {
          kf.push({ ...kf[kf.length - 1], offset: off(times[i]) });
          kf.push({ offset: off(times[i]), ...state(st) });
        });
        return kf;
      };

      // Каретка: тонкая, в рост строки; после набора мигает и гаснет
      const caret = document.createElement('div');
      caret.className = 'type-caret k-' + role;
      caret.style.width = Math.max(1.5, R[0].h * .028).toFixed(1) + 'px';
      s.layer.append(caret);
      const ck = track(st => ({ transform: `translate3d(${px(st.cx)},${px(st.cy)},0)`, height: px(st.ch), opacity: 1 }));
      const lastK = ck[ck.length - 1];
      [[t1 + 70, 0], [t1 + 150, 1], [t1 + 230, 0]].forEach(([ms, o]) => {
        ck.push({ ...ck[ck.length - 1], offset: off(ms) }, { ...lastK, offset: off(ms), opacity: o });
      });
      ck.push({ ...ck[ck.length - 1], offset: 1 });
      s.add(caret, ck, { delay: t0, duration: span, easing: 'linear', fill: 'forwards' });

      // Поле растёт вслед за текстом, без маркеров, пока идёт набор
      const box = document.createElement('div');
      box.className = 'intro-frame type-box k-' + role;
      Object.assign(box.style, { left: px(x0), top: px(y0) });
      s.layer.append(box);
      const bk = track(st => ({ width: px(st.w), height: px(st.h), opacity: 1 }));
      const lb = bk[bk.length - 1];
      bk.push({ ...lb, offset: off(tSel) }, { ...lb, offset: off(tSel), opacity: 0 }, { ...lb, offset: 1, opacity: 0 });
      s.add(box, bk, { delay: t0, duration: span, easing: 'linear', fill: 'forwards' });

      // Набор закончен: поле выделено маркерами, затем выделение снимается
      const fin = steps[steps.length - 1];
      const sel = frame(s, { x: x0, y: y0, w: fin.w, h: fin.h }, role);
      s.add(sel, [{ opacity: 1 }, { opacity: 1, offset: .6 }, { opacity: 0 }], { delay: tSel, duration: tEnd - tSel, easing: 'linear', fill: 'none' });

      const cc = c || GHOST;
      if (cc.real) {
        cc.go(t0 - 40, at);
        cc.press(t0 - 90, t0 - 10);
        cc.beam(t0 - 60, t1 + 50);
      }
      return { at, end: tEnd };
    }
    return { box0, at, run };
  }

  // Строки текста элемента (в координатах сцены): по прямоугольникам Range, склеенным по высоте
  function lineBoxes(s, el) {
    const range = document.createRange();
    range.selectNodeContents(el);
    const E = el.getBoundingClientRect(), H = s.hostRect;
    const rs = [...range.getClientRects()].filter(r => r.width > 1 && r.height > 1 && r.top >= E.top - 2 && r.bottom <= E.bottom + 2);
    const out = [];
    rs.sort((a, b) => a.top - b.top).forEach(r => {
      const m = (r.top + r.bottom) / 2;
      const L = out.find(l => m > l.top && m < l.bottom);
      if (L) { L.left = Math.min(L.left, r.left); L.right = Math.max(L.right, r.right); L.top = Math.min(L.top, r.top); L.bottom = Math.max(L.bottom, r.bottom); }
      else out.push({ left: r.left, right: r.right, top: r.top, bottom: r.bottom });
    });
    return out.map(l => ({ x: l.left - H.left, y: l.top - H.top, w: l.right - l.left, h: l.bottom - l.top }));
  }

  /* Абзац проявляется группами строк (per строк в группе): группа подсвечивается, как выделение мышью,
     курсор-«балка» идёт по её концу. Сам текст открывается через clip-path, раскладка не меняется.
     dx — сдвиг абзаца в это время (если его же двигает другой курсор) */
  function lines(s, el, { c, t0, t1, per = 1, role = 'text', sweep = true, dx = 0 } = {}) {
    const B = s.rel(el);
    const L = lineBoxes(s, el);
    if (!L.length) { show(s, el, t0, { dur: Math.max(120, t1 - t0) }); return; }
    const groups = [];
    for (let i = 0; i < L.length; i += per) groups.push(L.slice(i, i + per));
    const n = groups.length, span = Math.max(1, t1 - t0) / n;
    // Шкала начинается чуть раньше первой группы: при двух кадрах с отметкой 0 до старта показывался бы второй
    const T0 = t0 - 20, D = t1 - T0;
    let prev = `inset(0px 0px ${px(B.h + 2)} 0px)`;
    const kf = [{ offset: 0, clipPath: prev }];
    groups.forEach((gr, i) => {
      const o = (t0 + i * span - T0) / D, lb = gr[gr.length - 1];
      const v = i === n - 1 ? 'inset(0px 0px 0px 0px)' : `inset(0px 0px ${px(Math.max(0, B.y + B.h - lb.y - lb.h - 1))} 0px)`;
      kf.push({ offset: o, clipPath: prev }, { offset: o, clipPath: v });
      prev = v;
    });
    kf.push({ offset: 1, clipPath: 'inset(0px 0px 0px 0px)' });
    s.add(el, kf, { delay: T0, duration: D, easing: 'linear' });

    if (sweep) groups.forEach((gr, i) => gr.forEach(l => {
      const h = document.createElement('div');
      h.className = 'k-hl k-' + role;
      Object.assign(h.style, { left: px(l.x + dx), top: px(l.y), width: px(l.w), height: px(l.h) });
      s.layer.append(h);
      s.add(h, [{ opacity: 0, scale: '0 1' }, { opacity: .26, scale: '1 1', offset: .4 }, { opacity: .26, scale: '1 1', offset: .6 }, { opacity: 0, scale: '1 1' }],
        { delay: t0 + i * span, duration: Math.max(360, span * 1.25), easing: 'linear' });
    }));

    const cc = c || GHOST;
    if (cc.real) {
      const f = groups[0][0];
      cc.go(t0, { x: f.x + dx, y: f.y + f.h / 2 });
      cc.press(t0 - 20, t1 + 20);
      cc.beam(t0 - 40, t1 + 60);
      groups.forEach((gr, i) => {
        const lb = gr[gr.length - 1];
        cc.seg(t0 + i * span, t0 + (i + .85) * span, { x: lb.x + lb.w + dx, y: lb.y + lb.h / 2 }, MOVE);
      });
    }
  }

  /* ---------- Пошаговый просмотр для разработки: ?step=1, клавиши «.» и «,» ---------- */

  if (stepMode) addEventListener('keydown', e => {
    if (e.key !== '.' && e.key !== ',') return;
    live.forEach(s => s.step(e.key === '.' ? 40 : -40));
  });

  window.Kit = { ok, dev, slow, stepMode, stage, live, EASE, MOVE, DRAG, SNAP, GHOST };
})();
