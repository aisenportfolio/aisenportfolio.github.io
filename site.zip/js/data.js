/*
  Работы портфолио. Чтобы добавить кейс, скопируйте объект целиком,
  поменяйте значения и положите картинки в assets/img. Вёрстку править не нужно.
  Поля, которых у кейса нет, можно удалить: пустые блоки на страницу не выводятся.

  Картинки: имя без ширины и расширения, доступные ширины перечислены в w.
  Файл edu-home-960.webp описывается как { src: 'assets/img/edu-home', w: [960, 1440], ratio: '1440 / 672' }.

  Конфиденциальность: название клиента, телефоны, контакты и ссылка на его сайт в кейсе
  не указываются, на скриншотах они убраны. Если у кейса есть публичная ссылка, добавьте
  поля url и urlLabel: появятся кнопка и строка «Сайт».
*/
window.CASES = [
  {
    slug: 'edu-app',
    year: '2026',
    client: 'Учебная группа, клиентский проект',
    title: 'Четыре ресурса собраны в одно приложение',
    summary: 'Курсы, цены, материалы и контакты были разбросаны по четырём сайтам и платформам. Собрал их в один сайт-приложение, который ставится на телефон.',
    role: ['Проектирование структуры и UX', 'Разработка', 'Деплой', 'Поддержка'],

    // Обложка карточки на главной
    cover: {
      desktop: { src: 'assets/img/edu-home', w: [960, 1440], ratio: '1440 / 672', alt: 'Главная страница сайта-приложения на компьютере' },
      mobile: { src: 'assets/img/edu-mobile', w: [500, 750], ratio: '500 / 1082', alt: 'Каталог курсов на телефоне' }
    },

    // Крупные цифры в начале кейса
    numbers: [
      { from: '4', fromLabel: 'ресурса, по которым была разбросана информация', to: '1', toLabel: 'точка входа: сайт-приложение' }
    ],
    facts: [
      { value: '180', label: 'программ обучения в одном каталоге' }
    ],

    problem: 'Информация и сервисы были разбросаны по четырём отдельным сайтам и платформам. Чтобы найти курс, цену, учебные материалы или контакты, клиенту приходилось переходить с одного ресурса на другой.',
    solution: 'Собрал из четырёх ресурсов один сайт-приложение (PWA). Каталог, цены, материалы, контакты и личный кабинет теперь находятся в одном месте.',

    before: [
      { name: 'Основной сайт', url: 'sakhatec.org' },
      { name: 'Moodle', url: 'edu.sakhatec.org' },
      { name: 'SkillSpace', url: 'stk14.skillspace.ru' },
      { name: 'Сайт курсов', url: 'стк-курсы.рф' }
    ],
    after: { name: 'Сайт-приложение', note: 'Каталог, цены, материалы, контакты и кабинет' },

    removed: [
      'Дублирующиеся страницы',
      'Устаревшая информация',
      'Лишние переходы между платформами'
    ],
    added: [
      'Единый каталог курсов',
      'Прайсы',
      'Учебные материалы',
      'Контакты',
      'Личный кабинет с курсами',
      'Простая регистрация: фамилия, имя, телефон',
      'Установка на телефон как приложение (PWA)',
      'Scroll-анимации на десктопе'
    ],
    easier: [
      'Всё в одном месте',
      'Меньше кликов до нужного курса',
      'Удобно с телефона',
      'Понятный путь от выбора курса до обучения'
    ],

    stack: [
      'HTML, CSS и JavaScript без фреймворков и сборки',
      'PWA: сервис-воркер и манифест приложения',
      'Хостинг Netlify'
    ],
    tools: ['Claude Code'],

    // Экраны внутри кейса. Широкий экран начинает ряд, экран с phone: true встаёт рядом с ним
    shots: [
      { src: 'assets/img/edu-courses', w: [960, 1440], ratio: '1440 / 900', alt: 'Каталог курсов: фильтры по направлениям и карточки программ', caption: 'Единый каталог: все программы с фильтрами по направлениям' },
      { src: 'assets/img/edu-home-m', w: [500, 750], ratio: '500 / 1082', alt: 'Главная страница на телефоне: поиск и выбор по цели', caption: 'Главная на телефоне: поиск и быстрый выбор по цели', phone: true },
      { src: 'assets/img/edu-course', w: [960, 1440], ratio: '1440 / 900', alt: 'Страница программы обучения с условиями и кнопкой записи', caption: 'Страница программы: кому подойдёт, как проходит обучение, какой документ выдаётся' },
      { src: 'assets/img/edu-mobile', w: [500, 750], ratio: '500 / 1082', alt: 'Каталог курсов на телефоне с нижним меню', caption: 'Каталог на телефоне. Сайт ставится на главный экран как приложение', phone: true },
      { src: 'assets/img/edu-quiz', w: [960, 1440], ratio: '1440 / 900', alt: 'Подбор курса: первый из трёх вопросов', caption: 'Подбор курса за три вопроса' },
      { src: 'assets/img/edu-cabinet-m', w: [500, 750], ratio: '500 / 1082', alt: 'Вход в личный кабинет на телефоне: фамилия, имя, телефон', caption: 'Вход в кабинет: фамилия, имя и телефон', phone: true }
    ]
  },
  {
    slug: 'mep',
    year: '2026',
    client: 'Собственный продукт, демо',
    title: 'Кошелёк для жизни между рублём и донгом',
    summary: 'Финтех-кошелёк для тех, кто живёт во Вьетнаме с доходом в рублях: пополнение, обмен по понятному курсу, оплата по QR и виртуальные карты. Спроектировал и собрал работающий демо-продукт: лендинг, веб-приложение и версию для телефона.',
    role: ['Продуктовая логика и UX', 'Дизайн-система', 'Разработка: интерфейс и сервер', 'Деплой и поддержка'],
    url: 'https://modern-e-payment.netlify.app',
    urlLabel: 'Открыть демо',

    // Обложка карточки на главной
    cover: {
      desktop: { src: 'assets/img/mep-home', w: [960, 1440], ratio: '1440 / 672', alt: 'Первый экран сайта MEP на компьютере' },
      mobile: { src: 'assets/img/mep-app-m', w: [500, 750], ratio: '375 / 812', alt: 'Главный экран кошелька на телефоне' }
    },

    facts: [
      { value: '10', label: 'экранов кошелька: от баланса до истории операций' },
      { value: '3', label: 'языка интерфейса: русский, английский, вьетнамский' },
      { value: '30 с', label: 'курс и комиссия фиксируются перед обменом' }
    ],

    problem: 'Тем, кто живёт во Вьетнаме и получает доход в рублях, приходится собирать платёжную цепочку из обменников, переводов и чужих карт. Курс и комиссия становятся понятны уже после сделки, а местный QR российской картой не оплатить.',
    solution: 'Собрал демо-продукт кошелька. Счёт пополняется в рублях, обмен показывает курс и комиссию до подтверждения и держит их 30 секунд, оплата проходит по вьетнамскому QR. Платежи в демо имитируются, настоящие деньги не списываются, но путь пользователя пройден целиком: от регистрации с кодом из письма до квитанции.',

    added: [
      'Регистрация с кодом из письма и проверкой возраста 18+, вход через Google',
      'Счета в рублях, долларах, донгах и криптовалюте',
      'Обмен с фиксацией курса и сравнением с обменниками',
      'Оплата по VietQR: сканер камеры и ввод кода',
      'Виртуальные карты с лимитами и заморозкой',
      'Тарифы с лимитами и комиссиями',
      'История операций, квитанции в PDF и выгрузка в CSV',
      'Подтверждение операций PIN-кодом, двухфакторная защита, список активных сессий',
      'Установка на телефон как приложение (PWA) и офлайн-экран'
    ],
    easier: [
      'Курс и комиссия видны до подтверждения',
      'Одинаково удобно с телефона и с компьютера',
      'Светлая и тёмная темы, три языка',
      'Живые курсы из открытых источников'
    ],

    stack: [
      'Next.js 15, React 19, TypeScript',
      'Tailwind CSS и Framer Motion',
      'PostgreSQL и Prisma',
      'Auth.js: почта с кодом и Google',
      'PWA: сервис-воркер и манифест приложения',
      'Хостинг Netlify'
    ],
    tools: ['Claude Code'],

    // Экраны внутри кейса. Широкий экран начинает ряд, экран с phone: true встаёт рядом с ним
    shots: [
      { src: 'assets/img/mep-dashboard', w: [960, 1440], ratio: '1440 / 900', alt: 'Главный экран кошелька: общий баланс, счета, курсы и последние операции', caption: 'Главная: баланс, счета, живые курсы и последние операции' },
      { src: 'assets/img/mep-exchange-m', w: [500, 750], ratio: '375 / 812', phone: true, alt: 'Обмен рублей на донги на телефоне', caption: 'Обмен на телефоне: курс держится 30 секунд' },
      { src: 'assets/img/mep-exchange', w: [960, 1440], ratio: '1440 / 900', alt: 'Экран обмена: сумма, курс, комиссия и сравнение с обменниками', caption: 'Обмен: курс и комиссия видны до подтверждения, рядом сравнение с обменниками' },
      { src: 'assets/img/mep-cards-m', w: [500, 750], ratio: '375 / 812', phone: true, alt: 'Виртуальная карта на телефоне', caption: 'Виртуальные карты: баланс, лимит, заморозка' },
      { src: 'assets/img/mep-tiers', w: [960, 1440], ratio: '1440 / 900', alt: 'Четыре тарифа кошелька с лимитами и комиссиями', caption: 'Тарифы: лимиты и комиссии растут вместе с оборотом' },
      { src: 'assets/img/mep-home-m', w: [500, 750], ratio: '375 / 812', phone: true, alt: 'Первый экран сайта на телефоне', caption: 'Лендинг на телефоне' }
    ]
  },
  {
    slug: 'prokat',
    year: '2026',
    client: 'Шаблон для автопрокатов, демо',
    title: 'Сайт проката: от выбора машины до запроса менеджеру',
    summary: 'Сайт для проката автомобилей: каталог с фильтрами, выбор дат и места получения, примерный расчёт стоимости и готовый текст запроса менеджеру. Все данные компании лежат в одном файле настроек, поэтому сайт быстро переносится на конкретный прокат.',
    role: ['Проектирование структуры и UX', 'Разработка', 'Деплой'],
    url: 'https://prokat-avto-demo.pages.dev/',
    urlLabel: 'Открыть демо',

    // Обложка карточки на главной
    cover: {
      desktop: { src: 'assets/img/prk-home', w: [960, 1440], ratio: '1440 / 800', alt: 'Первый экран сайта проката: выбор автомобиля и дат' },
      mobile: { src: 'assets/img/prk-home-m', w: [500, 750], ratio: '500 / 1082', alt: 'Первый экран сайта проката на телефоне' }
    },

    facts: [
      { value: '8', label: 'автомобилей в демо-каталоге, 5 классов' },
      { value: '4', label: 'места получения и возврата с доплатами' },
      { value: '1', label: 'файл настроек: название, цены, условия, контакты' }
    ],

    problem: 'Прокату нужен сайт, на котором клиент сам выбирает машину, даты и место получения, видит условия заранее, а менеджер получает запрос со всеми параметрами.',
    solution: 'Собрал сайт-шаблон. Клиент подбирает автомобиль, указывает даты, время и место, добавляет услуги, и сайт собирает из этого понятный текст запроса. В демо заявки не отправляются: наличие и итоговую стоимость подтверждает менеджер.',

    added: [
      'Каталог с фильтрами по классу и коробке передач и сортировкой',
      'Подробности автомобиля в отдельном окне',
      'Выбор дат и времени с учётом часов работы и местного времени',
      'Места получения и возврата: офис, вокзал, аэропорт, доставка',
      'Дополнительные услуги: детское кресло, второй водитель, багажный бокс',
      'Расчёт стоимости по ступеням тарифа, залог отдельно от аренды',
      'Готовый текст запроса менеджеру',
      'Каналы связи (WhatsApp, Telegram, телефон, почта) включаются в настройках',
      'Светлая и тёмная темы, блоки «Как арендовать», условия и вопросы'
    ],
    easier: [
      'Условия и примерная стоимость видны до обращения',
      'Менеджер получает запрос со всеми параметрами сразу',
      'Под новый прокат меняется один файл, а не вёрстка',
      'Удобно с телефона'
    ],

    stack: [
      'HTML, CSS и JavaScript-модули без фреймворков и сборки',
      'Шрифты на своём сервере, строгая политика безопасности (CSP)',
      'Изображения автомобилей — иллюстрации, обработанные ИИ',
      'Хостинг Cloudflare Pages'
    ],
    tools: ['ChatGPT Codex'],

    // Экраны внутри кейса. Широкий экран начинает ряд, экран с phone: true встаёт рядом с ним
    shots: [
      { src: 'assets/img/prk-cars', w: [960, 1440], ratio: '1440 / 900', alt: 'Каталог автомобилей с фильтрами и ценами', caption: 'Каталог: фильтры по классу и коробке, пример тарифа за сутки' },
      { src: 'assets/img/prk-cars-m', w: [500, 750], ratio: '500 / 1082', alt: 'Каталог автомобилей на телефоне', caption: 'Каталог на телефоне', phone: true },
      { src: 'assets/img/prk-booking', w: [960, 1440], ratio: '1440 / 900', alt: 'Форма запроса на аренду со сводкой справа', caption: 'Запрос на аренду: шаги слева, сводка и стоимость справа' },
      { src: 'assets/img/prk-booking-m', w: [500, 750], ratio: '500 / 1082', alt: 'Форма запроса на телефоне', caption: 'Та же форма на телефоне', phone: true },
      { src: 'assets/img/prk-terms', w: [960, 1440], ratio: '1440 / 900', alt: 'Условия аренды: документы, залог, пробег, топливо', caption: 'Условия аренды коротко, подробности раскрываются по нажатию' },
      { src: 'assets/img/prk-home-m', w: [500, 750], ratio: '500 / 1082', alt: 'Первый экран на телефоне', caption: 'Первый экран на телефоне', phone: true }
    ]
  },
  {
    slug: 'banket',
    year: '2026',
    client: 'Собственный проект',
    title: 'Каталог банкетных залов Москвы',
    summary: 'Независимый каталог реальных банкетных залов: быстрый подбор по формату и числу гостей, фильтры, поиск и сохранённые залы. Из карточки можно сразу перейти на сайт площадки и к карте, без посредников.',
    role: ['Проектирование структуры и UX', 'Дизайн', 'Разработка'],
    url: 'https://banket.pages.dev/',
    urlLabel: 'Открыть сайт',

    // Обложка карточки на главной
    cover: {
      desktop: { src: 'assets/img/bnk-home', w: [960, 1440], ratio: '1440 / 800', alt: 'Первый экран каталога банкетных залов с быстрым подбором' },
      mobile: { src: 'assets/img/bnk-home-m', w: [500, 750], ratio: '500 / 1082', alt: 'Первый экран каталога на телефоне' }
    },

    facts: [
      { value: '9', label: 'реальных залов, данные сверены с сайтами площадок' },
      { value: '12–850', label: 'гостей: вместимость залов в подборке' }
    ],

    problem: 'Чтобы выбрать зал для свадьбы или корпоратива, приходится открывать десятки сайтов площадок и сравнивать вместимость и формат вручную.',
    solution: 'Собрал каталог, где залы сравниваются по одним признакам: формат события, вместимость, тип места и район. Сайт не принимает бронирования: свободные даты и цены подтверждает сама площадка, а каталог ведёт прямо на её сайт.',

    added: [
      'Быстрый подбор на первом экране: формат события и число гостей',
      'Фильтры по формату, вместимости и типу площадки',
      'Поиск по названию, району и адресу, сортировка по вместимости',
      'Сохранённые и недавно просмотренные залы в браузере',
      'Карточки с адресом, источником данных, переходом на сайт площадки и картой',
      'Слайд-шоу реальных залов на первом экране, появление блоков, плавные окна',
      'Подсказки, что уточнить перед бронированием'
    ],
    easier: [
      'Залы сравниваются по одним и тем же признакам',
      'Подходящие варианты видны за два выбора на первом экране',
      'Без посредников: переход сразу на сайт площадки',
      'Удобно с телефона, уменьшенная анимация уважается'
    ],

    stack: [
      'HTML, CSS и JavaScript без фреймворков и сборки',
      'Адаптивная вёрстка от 390 px, поддержка prefers-reduced-motion'
    ],
    tools: ['ChatGPT Codex'],

    // Экраны внутри кейса. Широкий экран начинает ряд, экран с phone: true встаёт рядом с ним
    shots: [
      { src: 'assets/img/bnk-catalog', w: [960, 1440], ratio: '1440 / 900', alt: 'Каталог: вкладки форматов, фильтры и карточки залов', caption: 'Каталог: вкладки по формату события, фильтры и поиск' },
      { src: 'assets/img/bnk-catalog-m', w: [500, 750], ratio: '500 / 1082', alt: 'Фильтры каталога на телефоне', caption: 'Фильтры на телефоне', phone: true },
      { src: 'assets/img/bnk-cards', w: [960, 1440], ratio: '1440 / 900', alt: 'Карточки залов с вместимостью и районом', caption: 'Карточки: район, вместимость, переход к залу и сохранение' },
      { src: 'assets/img/bnk-cards-m', w: [500, 750], ratio: '500 / 1082', alt: 'Карточки залов на телефоне', caption: 'Карточки на телефоне', phone: true },
      { src: 'assets/img/bnk-tips', w: [960, 1440], ratio: '1440 / 900', alt: 'Блок «Что стоит уточнить» и подвал сайта', caption: 'Что уточнить перед бронированием: даты, стоимость, расстановка' },
      { src: 'assets/img/bnk-home-m', w: [500, 750], ratio: '500 / 1082', alt: 'Первый экран на телефоне', caption: 'Первый экран на телефоне', phone: true }
    ]
  },
  {
    slug: 'phone-shop',
    year: '2026',
    client: 'Магазин электроники',
    title: 'Каталог техники с заказом в один клик',
    summary: 'Каталог магазина оригинальной электроники: 19 моделей с вариантами цвета, памяти и SIM. Цена пересчитывается при выборе варианта, а кнопка «Уточнить и заказать» готовит сообщение менеджеру с выбранным товаром.',
    role: ['Проектирование структуры и UX', 'Дизайн', 'Разработка', 'Деплой'],
    url: 'https://shop-catalog-2026.pages.dev/',
    urlLabel: 'Открыть сайт',

    // Обложка карточки на главной
    cover: {
      desktop: { src: 'assets/img/shop-home', w: [960, 1440], ratio: '1440 / 800', alt: 'Первый экран каталога с новыми смартфонами' },
      mobile: { src: 'assets/img/shop-catalog-m', w: [500, 750], ratio: '500 / 1082', alt: 'Каталог техники на телефоне' }
    },

    facts: [
      { value: '19', label: 'моделей в каталоге, 10 категорий' },
      { value: '4', label: 'шага от выбора до доставки' }
    ],

    problem: 'Покупатели выбирают технику по прайсу и пишут менеджеру, какую модель, цвет и объём памяти они хотят. Каждый заказ начинается с уточнений в переписке.',
    solution: 'Собрал каталог, где покупатель сам выбирает модель и вариант, сразу видит цену по прайсу, а сообщение менеджеру с выбранным товаром собирается автоматически.',

    added: [
      'Категории, поиск и фильтры по цене, бренду, памяти и SIM',
      'Сортировка по цене и по порядку прайса',
      'Выбор цвета, памяти и SIM прямо в карточке, цена пересчитывается',
      'Фото товара с пяти ракурсов',
      'Кнопка «Уточнить и заказать» с выбранным товаром и вариантом',
      'Блоки «Как купить», «О магазине», условия гарантии, доставки и рассрочки',
      'Заказ модели, которой нет в каталоге'
    ],
    easier: [
      'Цена видна сразу для выбранного варианта',
      'Менеджер получает запрос с точной моделью и вариантом',
      'Удобно с телефона'
    ],

    stack: [
      'Одна HTML-страница: CSS и JavaScript без фреймворков',
      'Каталог из данных прайса, фото в WebP',
      'Хостинг Cloudflare Pages'
    ],

    // Экраны внутри кейса. Широкий экран начинает ряд, экран с phone: true встаёт рядом с ним
    shots: [
      { src: 'assets/img/shop-catalog', w: [960, 1440], ratio: '1440 / 900', alt: 'Каталог: категории, фильтры и карточки смартфонов с выбором варианта', caption: 'Каталог: категории, фильтры и выбор варианта в карточке' },
      { src: 'assets/img/shop-catalog-m', w: [500, 750], ratio: '500 / 1082', alt: 'Каталог на телефоне', caption: 'Каталог на телефоне', phone: true },
      { src: 'assets/img/shop-how', w: [960, 1440], ratio: '1440 / 780', alt: 'Как купить, о магазине и условия', caption: 'Как купить: четыре шага, условия гарантии, доставки и рассрочки' },
      { src: 'assets/img/shop-card-m', w: [500, 750], ratio: '500 / 1082', alt: 'Карточки товаров на телефоне', caption: 'Карточки с ценой и кнопкой заказа', phone: true },
      { src: 'assets/img/shop-home', w: [960, 1440], ratio: '1440 / 800', alt: 'Заголовок первого экрана и кнопки', caption: 'Первый экран: новинка, условия и переход в каталог' },
      { src: 'assets/img/shop-home-m', w: [500, 750], ratio: '500 / 1082', alt: 'Первый экран на телефоне', caption: 'Первый экран на телефоне', phone: true }
    ]
  }
];

/*
  Английские версии кейсов. Поля поверх русских (js/app.js, loc): картинки, ссылки и цифры общие,
  переводятся тексты. Массивы shots, before, numbers, facts идут в том же порядке, что в CASES.
*/
window.CASES_EN = {
  'edu-app': {
    client: 'Training centre (client project)',
    title: 'Four resources merged into one app',
    summary: 'Courses, prices, materials and contacts were spread across four websites and platforms. I combined them into one web app that can be installed on a phone.',
    role: ['Structure and UX design', 'Development', 'Deployment', 'Support'],
    cover: { desktop: { alt: 'Home page of the web app on desktop' }, mobile: { alt: 'Course catalogue on a phone' } },
    numbers: [{ fromLabel: 'resources the information was spread across', toLabel: 'entry point: one web app' }],
    facts: [{ label: 'training programmes in one catalogue' }],
    problem: 'Information and services were spread across four separate websites and platforms. To find a course, a price, study materials or contacts, customers had to jump from one resource to another.',
    solution: 'I combined the four resources into one web app (PWA). The catalogue, prices, materials, contacts and personal account are now in one place.',
    before: [{ name: 'Main website' }, { name: 'Moodle' }, { name: 'SkillSpace' }, { name: 'Courses website' }],
    after: { name: 'Web app', note: 'Catalogue, prices, materials, contacts and account' },
    removed: ['Duplicate pages', 'Outdated information', 'Extra jumps between platforms'],
    added: ['One course catalogue', 'Price lists', 'Study materials', 'Contacts', 'Personal account with courses', 'Simple sign-up: surname, first name, phone', 'Install on a phone as an app (PWA)', 'Scroll animations on desktop'],
    easier: ['Everything in one place', 'Fewer clicks to the right course', 'Easy to use from a phone', 'A clear path from choosing a course to studying'],
    stack: ['HTML, CSS and JavaScript without frameworks or a build step', 'PWA: service worker and app manifest', 'Hosting: Netlify'],
    shots: [
      { alt: 'Course catalogue: filters by area and programme cards', caption: 'One catalogue: every programme with filters by area' },
      { alt: 'Home page on a phone: search and choice by goal', caption: 'Home page on a phone: search and quick choice by goal' },
      { alt: 'Programme page with terms and an enrol button', caption: 'Programme page: who it suits, how training works, which certificate is issued' },
      { alt: 'Course catalogue on a phone with a bottom menu', caption: 'Catalogue on a phone. The site installs on the home screen as an app' },
      { alt: 'Course finder: the first of three questions', caption: 'Course finder in three questions' },
      { alt: 'Account sign-in on a phone: surname, first name, phone', caption: 'Account sign-in: surname, first name and phone' }
    ]
  },

  'mep': {
    client: 'Own product (demo)',
    title: 'A wallet for life between the rouble and the dong',
    summary: 'A fintech wallet for people living in Vietnam with income in roubles: top-ups, exchange at a clear rate, QR payments and virtual cards. I designed and built a working demo: landing page, web app and phone version.',
    role: ['Product logic and UX', 'Design system', 'Development: interface and server', 'Deployment and support'],
    urlLabel: 'Open demo',
    cover: { desktop: { alt: 'MEP first screen on desktop' }, mobile: { alt: 'Wallet home screen on a phone' } },
    facts: [
      { label: 'wallet screens, from balance to transaction history' },
      { label: 'interface languages: Russian, English, Vietnamese' },
      { value: '30 s', label: 'the rate and fee are locked before an exchange' }
    ],
    problem: 'People who live in Vietnam and earn in roubles have to piece together a payment chain from exchangers, transfers and other people’s cards. The rate and fee only become clear after the deal, and a Russian card cannot pay a local QR code.',
    solution: 'I built a demo wallet. The account is topped up in roubles, the exchange shows the rate and fee before confirmation and holds them for 30 seconds, and payments go through Vietnamese QR codes. Payments in the demo are simulated and no real money moves, but the whole user path is covered, from sign-up with an email code to the receipt.',
    added: [
      'Sign-up with an email code and an 18+ age check, Google sign-in',
      'Accounts in roubles, dollars, dong and cryptocurrency',
      'Exchange with a locked rate and a comparison with exchangers',
      'VietQR payments: camera scanner and code entry',
      'Virtual cards with limits and freezing',
      'Plans with limits and fees',
      'Transaction history, PDF receipts and CSV export',
      'PIN confirmation for operations, two-factor protection, active sessions list',
      'Install on a phone as an app (PWA) and an offline screen'
    ],
    easier: ['The rate and fee are visible before confirmation', 'Equally easy on phone and desktop', 'Light and dark themes, three languages', 'Live rates from open sources'],
    stack: ['Next.js 15, React 19, TypeScript', 'Tailwind CSS and Framer Motion', 'PostgreSQL and Prisma', 'Auth.js: email code and Google', 'PWA: service worker and app manifest', 'Hosting: Netlify'],
    shots: [
      { alt: 'Wallet home: total balance, accounts, rates and recent transactions', caption: 'Home: balance, accounts, live rates and recent transactions' },
      { alt: 'Exchanging roubles for dong on a phone', caption: 'Exchange on a phone: the rate is held for 30 seconds' },
      { alt: 'Exchange screen: amount, rate, fee and comparison with exchangers', caption: 'Exchange: the rate and fee are visible before confirmation, next to a comparison with exchangers' },
      { alt: 'Virtual card on a phone', caption: 'Virtual cards: balance, limit, freezing' },
      { alt: 'Four wallet plans with limits and fees', caption: 'Plans: limits and fees grow with turnover' },
      { alt: 'Site first screen on a phone', caption: 'Landing page on a phone' }
    ]
  },

  'prokat': {
    client: 'Template for car rental companies (demo)',
    title: 'Car rental site: from choosing a car to a request for the manager',
    summary: 'A website for a car rental company: a catalogue with filters, choice of dates and pick-up point, an estimated price and a ready request text for the manager. All company data lives in one settings file, so the site is quick to adapt to a specific rental company.',
    role: ['Structure and UX design', 'Development', 'Deployment'],
    urlLabel: 'Open demo',
    cover: { desktop: { alt: 'Rental site first screen: choosing a car and dates' }, mobile: { alt: 'Rental site first screen on a phone' } },
    facts: [
      { label: 'cars in the demo catalogue, 5 classes' },
      { label: 'pick-up and return points with surcharges' },
      { label: 'settings file: name, prices, terms, contacts' }
    ],
    problem: 'A rental company needs a website where customers choose a car, dates and pick-up point themselves, see the terms in advance, and the manager receives a request with all the details.',
    solution: 'I built a website template. The customer picks a car, sets dates, time and place, adds extras, and the site turns this into a clear request text. In the demo, requests are not sent: availability and the final price are confirmed by the manager.',
    added: [
      'Catalogue with filters by class and transmission, and sorting',
      'Car details in a separate window',
      'Date and time selection that respects opening hours and local time',
      'Pick-up and return points: office, station, airport, delivery',
      'Extras: child seat, second driver, roof box',
      'Price by rate tiers, deposit kept separate from the rental',
      'Ready request text for the manager',
      'Contact channels (WhatsApp, Telegram, phone, email) switch on in settings',
      'Light and dark themes, “How to rent”, terms and FAQ sections'
    ],
    easier: ['Terms and an estimated price are visible before contacting', 'The manager receives a request with every detail at once', 'For a new rental company you change one file, not the layout', 'Easy to use from a phone'],
    stack: ['HTML, CSS and JavaScript modules without frameworks or a build step', 'Self-hosted fonts, strict security policy (CSP)', 'Car images are AI-processed illustrations', 'Hosting: Cloudflare Pages'],
    shots: [
      { alt: 'Car catalogue with filters and prices', caption: 'Catalogue: filters by class and transmission, sample daily rate' },
      { alt: 'Car catalogue on a phone', caption: 'Catalogue on a phone' },
      { alt: 'Rental request form with a summary on the right', caption: 'Rental request: steps on the left, summary and price on the right' },
      { alt: 'Request form on a phone', caption: 'The same form on a phone' },
      { alt: 'Rental terms: documents, deposit, mileage, fuel', caption: 'Rental terms in brief, details open on tap' },
      { alt: 'First screen on a phone', caption: 'First screen on a phone' }
    ]
  },

  'banket': {
    client: 'Own project',
    title: 'Catalogue of banquet halls in Moscow',
    summary: 'An independent catalogue of real banquet halls: quick matching by event type and number of guests, filters, search and saved halls. Each card links straight to the venue’s website and map, with no middleman.',
    role: ['Structure and UX design', 'Design', 'Development'],
    urlLabel: 'Open site',
    cover: { desktop: { alt: 'Banquet hall catalogue first screen with quick matching' }, mobile: { alt: 'Catalogue first screen on a phone' } },
    facts: [
      { label: 'real halls, data checked against the venues’ websites' },
      { label: 'guests: capacity range of the halls in the selection' }
    ],
    problem: 'To choose a hall for a wedding or a corporate event, people have to open dozens of venue websites and compare capacity and format by hand.',
    solution: 'I built a catalogue where halls are compared on the same criteria: event type, capacity, venue type and district. The site does not take bookings: free dates and prices are confirmed by the venue, and the catalogue links straight to its website.',
    added: [
      'Quick matching on the first screen: event type and number of guests',
      'Filters by event type, capacity and venue type',
      'Search by name, district and address, sorting by capacity',
      'Saved and recently viewed halls in the browser',
      'Cards with address, data source, link to the venue’s site and map',
      'Slideshow of real halls on the first screen, revealing blocks, smooth windows',
      'Tips on what to check before booking'
    ],
    easier: ['Halls are compared on the same criteria', 'Suitable options appear after two choices on the first screen', 'No middleman: a direct link to the venue’s site', 'Easy to use from a phone, reduced motion respected'],
    stack: ['HTML, CSS and JavaScript without frameworks or a build step', 'Responsive layout from 390 px, prefers-reduced-motion support'],
    shots: [
      { alt: 'Catalogue: event type tabs, filters and hall cards', caption: 'Catalogue: tabs by event type, filters and search' },
      { alt: 'Catalogue filters on a phone', caption: 'Filters on a phone' },
      { alt: 'Hall cards with capacity and district', caption: 'Cards: district, capacity, link to the hall and saving' },
      { alt: 'Hall cards on a phone', caption: 'Cards on a phone' },
      { alt: '“What to check” block and site footer', caption: 'What to check before booking: dates, price, table layout' },
      { alt: 'First screen on a phone', caption: 'First screen on a phone' }
    ]
  },

  'phone-shop': {
    client: 'Electronics store',
    title: 'Electronics catalogue with one-click ordering',
    summary: 'A catalogue for an original electronics store: 19 models with colour, storage and SIM options. The price updates when an option is chosen, and the “Ask and order” button prepares a message to the manager with the selected product.',
    role: ['Structure and UX design', 'Design', 'Development', 'Deployment'],
    urlLabel: 'Open site',
    cover: { desktop: { alt: 'Catalogue first screen with new smartphones' }, mobile: { alt: 'Electronics catalogue on a phone' } },
    facts: [
      { label: 'models in the catalogue, 10 categories' },
      { label: 'steps from choice to delivery' }
    ],
    problem: 'Customers pick products from a price list and write to the manager which model, colour and storage they want. Every order starts with back-and-forth clarifications.',
    solution: 'I built a catalogue where the customer chooses the model and option, sees the price from the price list straight away, and the message to the manager with the selected product is put together automatically.',
    added: [
      'Categories, search and filters by price, brand, storage and SIM',
      'Sorting by price and by price-list order',
      'Colour, storage and SIM choice right in the card, the price updates',
      'Product photos from five angles',
      '“Ask and order” button with the selected product and option',
      '“How to buy” and “About the store” sections, warranty, delivery and instalment terms',
      'Ordering a model that is not in the catalogue'
    ],
    easier: ['The price is visible at once for the chosen option', 'The manager receives a request with the exact model and option', 'Easy to use from a phone'],
    stack: ['A single HTML page: CSS and JavaScript without frameworks', 'Catalogue built from price-list data, WebP photos', 'Hosting: Cloudflare Pages'],
    shots: [
      { alt: 'Catalogue: categories, filters and smartphone cards with option choice', caption: 'Catalogue: categories, filters and option choice in the card' },
      { alt: 'Catalogue on a phone', caption: 'Catalogue on a phone' },
      { alt: 'How to buy, about the store and terms', caption: 'How to buy: four steps, warranty, delivery and instalment terms' },
      { alt: 'Product cards on a phone', caption: 'Cards with price and order button' },
      { alt: 'First screen headline and buttons', caption: 'First screen: new arrival, terms and a link to the catalogue' },
      { alt: 'First screen on a phone', caption: 'First screen on a phone' }
    ]
  }
};
