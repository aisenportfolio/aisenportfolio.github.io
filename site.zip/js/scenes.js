/* Сборка страницы при прокрутке: несколько виртуальных курсоров (js/kit.js) собирают блоки, как команда
   в Figma. У каждой карточки, строки навыков, шага и контакта своя короткая сцена из настоящих частей:
   контейнер, картинка, подпись, заголовок, описание, кнопка. Действия внутри сцены идут внахлёст,
   соседние сцены тоже могут идти одновременно.

   Блок (unit) — то, что собирается отдельно. У блока стабильный id и своё состояние:
     idle    — ничего не сделано, блок виден как обычно;
     armed   — блок подходит к окну снизу и заранее спрятан. Скрытие — конечная анимация: если скрипт
               сломается, блок всё равно покажется; пока блок ждёт, скрытие обновляется;
     queued  — блок в окне и ждёт старта (соседи по ряду стартуют со сдвигом 230 мс);
     running — сцена идёт;
     done    — блок показан готовым. id запоминается до конца сессии вкладки, при прокрутке назад
               ничего не пересобирается.
   Решения принимает одна проверка check() по фактическим координатам блоков, поэтому порядок событий
   неважен: блок, который уже в зоне запуска, сразу получает верное состояние.

   Быстрая прокрутка: пока скорость высокая, блоки в окне не стартуют; ушедшие вверх показываются готовыми;
   на блоке, где посетитель остановился, играет короткая сцена; блоки ниже ждут своей очереди.
   Курсоров на экране не больше пяти (на телефоне два); сцене, которой курсор не достался, приходится
   подождать, а если ждать долго — она идёт без курсора.

   Смена языка завершает идущие сцены и снимает подготовку с остальных: не показанные блоки соберутся
   позже, при прокрутке. Смена ширины окна завершает идущие сцены. Нажатие или фокус внутри блока сразу
   показывают его готовым. Прокрутку, указатель и фокус сцены не перехватывают.

   Отключено при prefers-reduced-motion. ?intro=1 — все сцены заново.
   Для разработки (только на своём компьютере): ?slow=4 — всё в 4 раза медленнее;
   ?scenetest=card:mep&sceneseek=800 — страница встаёт на блок, сцена замирает на 0,8 с;
   ?step=1 — клавиши «.» и «,» двигают замершие сцены на 40 мс; Scenes.debug() — состояния блоков. */
(() => {
  'use strict';

  const Kit = window.Kit;
  const Scenes = window.Scenes = { running: false, finish() {}, releaseAll() {}, caseOpen() {}, caseClose() {}, debug() { return null; } };
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (calm || !Kit || !Kit.ok) return;

  const root = document.documentElement;
  const query = location.search;
  const force = /[?&]intro=1(&|$)/.test(query);
  const test = Kit.dev && /[?&]scenetest=([\w:-]+)/.exec(query);
  const seekM = Kit.dev && /[?&]sceneseek=(\d+)/.exec(query);
  const { DRAG, SNAP } = Kit;
  const WIPE = 'cubic-bezier(.6,.05,.3,1)';    // протяжка линии: разгон и мягкая остановка, без рывка в начале

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  /* ---------- Показанные блоки ---------- */

  const KEY = 'scenesDone';
  let saved = new Set();
  try {
    sessionStorage.removeItem('scenesSeen');                 // ключ прежней версии
    if (force) sessionStorage.removeItem(KEY);
    saved = new Set(JSON.parse(sessionStorage.getItem(KEY) || '[]'));
  } catch (e) { saved = new Set(); }
  const save = () => { try { sessionStorage.setItem(KEY, JSON.stringify([...saved])); } catch (e) { /* без хранилища сцены просто повторятся */ } };

  /* ---------- Сцены блоков ---------- */

  // Заголовок раздела набирается очередями знаков
  function heading(s, el, { k }) {
    const c = s.cursor('text');
    const n = el.textContent.trim().length;
    const t0 = 260, t1 = t0 + clamp(n * 24, 260, 560);
    const typed = s.type(el, '.ln > span', { c, t0, t1, pad: 6 });
    if (typed.at) c.exit(typed.end - 60, { x: 30 * k, y: -24 * k });
  }

  // Части карточки работы
  const parts = card => ({
    shots: $('.card__shots', card), desk: $('.shot--desk', card), phone: $('.shot--phone', card),
    copy: $('.card__copy', card), client: $('.card__client', card), title: $('.card__title', card),
    text: $('.card__text', card), more: $('.card__more', card)
  });
  // Видимая часть картинки внутри обрезающей рамки
  const within = (s, el, box) => {
    const a = s.rel(el), b = s.rel(box);
    const x = Math.max(a.x, b.x), y = Math.max(a.y, b.y);
    return { x, y, w: Math.min(a.x + a.w, b.x + b.w) - x, h: Math.min(a.y + a.h, b.y + b.h) - y };
  };
  const radius = el => getComputedStyle(el).borderTopLeftRadius;
  // Рамка по самому тексту, а не по блоку на всю ширину колонки
  const textBox = (s, el) => {
    const L = s.lineBoxes(el);
    if (!L.length) return s.rel(el);
    const x = Math.min(...L.map(l => l.x)), y = L[0].y, r = Math.max(...L.map(l => l.x + l.w)), b = L[L.length - 1].y + L[L.length - 1].h;
    return { x, y, w: r - x, h: b - y };
  };

  // Учебная платформа: пустую карточку тянут сбоку, скриншот кладут, пока набирается заголовок
  function cardPull(s, card, { k }) {
    const P = parts(card), A = s.cursor('move'), B = s.cursor('media');
    s.drag(card, { c: A, grab: [.06, .3], frame: 'move', pad: 0, keys: [[100, { x: -86 * k }, DRAG], [520, { x: 6 * k }, SNAP], [640, {}]] });
    if (P.desk && P.shots) s.drag(P.desk, { c: B, grab: [.3, .4], box: within(s, P.desk, P.shots), frame: 'media', pad: 0,
      keys: [[360, { x: 44 * k, y: -30 * k }, DRAG], [720, { x: -4 * k, y: 2 * k }, SNAP], [820, {}]] });
    if (P.phone) s.drag(P.phone, { c: B, grab: [.5, .3], frame: 'media', pad: 3,
      keys: [[900, { x: -26 * k, y: 20 * k }, DRAG], [1120, { x: 2 * k }, SNAP], [1190, {}]] });
    if (P.client) s.show(P.client, 680, { y: 8 * k });
    if (P.title) s.type(P.title, null, { c: A, t0: 760, t1: 1180 });
    if (P.text) s.lines(P.text, { t0: 1080, t1: 1340, sweep: false });
    if (P.more) s.drag(P.more, { c: B, grab: [.5, .5], frame: 'media', pad: 4, keys: [[1260, { y: 18 * k }, DRAG], [1480, { y: -2 * k }, SNAP], [1560, {}]] });
    A.exit(1300); B.exit(1620);
  }

  // Кошелёк: контейнер растягивают за угол, заголовок набирают, кнопку ставят
  function cardStretch(s, card, { k }) {
    const P = parts(card), A = s.cursor('size'), B = s.cursor('text');
    s.crop(card, { c: A, handle: 'br', frame: 'size', round: radius(card), keys: [
      [100, [0, .55, .5, 0], DRAG], [520, [0, .05, .04, 0], 'linear'], [600, [0, .05, .04, 0], SNAP], [720, [0, 0, 0, 0]]
    ] });
    if (P.shots) s.drag(P.shots, { c: A, grab: [.5, .55], frame: 'size', pad: 0, keys: [[820, { y: 30 * k }, DRAG], [1100, { y: -2 * k }, SNAP], [1170, {}]] });
    if (P.client) s.show(P.client, 380, { x: -10 * k });
    if (P.title) s.type(P.title, null, { c: B, t0: 440, t1: 860 });
    if (P.text) s.lines(P.text, { c: B, t0: 920, t1: 1160 });
    if (P.more) s.drag(P.more, { c: B, grab: [.4, .5], frame: 'text', pad: 4, keys: [[1240, { x: 36 * k, y: 10 * k }, DRAG], [1480, { x: -3 * k }, SNAP], [1560, {}]] });
    A.exit(1220); B.exit(1620);
  }

  // Прокат: картинка открывается расширяющимся кадром, затем её подталкивают на место; текст собирается параллельно
  function cardCrop(s, card, { k }) {
    const P = parts(card), A = s.cursor('size'), B = s.cursor('text');
    s.show(card, 0, { dur: 220, sc: .985 });
    if (P.shots) s.crop(P.shots, { c: A, handle: 'br', frame: 'size', keys: [[120, [.32, .34, .32, .34], DRAG], [600, [0, 0, 0, 0]]] });
    if (P.desk && P.shots) s.drag(P.desk, { c: A, grab: [.25, .45], box: within(s, P.desk, P.shots), frame: 'size', pad: 0, appear: false,
      keys: [[720, { x: 18 * k, y: -8 * k }, DRAG], [980, { x: -2 * k }, SNAP], [1060, {}]] });
    if (P.client) s.show(P.client, 200, { y: -8 * k });
    if (P.title) s.type(P.title, null, { c: B, t0: 300, t1: 760 });
    if (P.text) s.lines(P.text, { c: B, t0: 840, t1: 1100 });
    if (P.more) s.drag(P.more, { c: B, grab: [.5, .5], frame: 'text', pad: 4, keys: [[1180, { x: -30 * k }, DRAG], [1400, { x: 3 * k }, SNAP], [1480, {}]] });
    A.exit(1120); B.exit(1540);
  }

  // Банкетные залы: карточка приезжает со сдвигом и лёгким поворотом и прилипает к направляющей; второй курсор заполняет текст
  function cardTilt(s, card, { k }) {
    const P = parts(card), A = s.cursor('move'), B = s.cursor('text');
    const C = s.rel(card), G = s.rel(card.parentElement);
    s.drag(card, { c: A, grab: [.5, .12], frame: 'move', pad: 0, keys: [[100, { y: 56 * k, r: -2 }, DRAG], [520, { y: -5 * k, r: .4 }, SNAP], [640, {}]] });
    s.guide({ x: G.x, y: C.y, w: G.w, h: 0 }, 460, 860, 'move');
    if (P.client) s.show(P.client, 560, { y: 8 * k });
    if (P.title) s.type(P.title, null, { c: B, t0: 620, t1: 1040 });
    if (P.text) s.lines(P.text, { c: B, t0: 1100, t1: 1340 });
    if (P.more) s.drag(P.more, { c: A, grab: [.5, .5], frame: 'move', pad: 4, keys: [[860, { x: 24 * k, y: 14 * k }, DRAG], [1100, { x: -2 * k }, SNAP], [1180, {}]] });
    A.exit(1240); B.exit(1400);
  }

  // Магазин: картинка и блок с текстом ставятся отдельно, отступ картинки поправляют, кнопку ставят
  function cardSplit(s, card, { k }) {
    const P = parts(card), A = s.cursor('media'), B = s.cursor('move');
    s.show(card, 0, { dur: 200 });
    if (P.shots) s.drag(P.shots, { c: A, grab: [.4, .45], frame: 'media', pad: 0, keys: [[100, { x: -30 * k, y: -22 * k }, DRAG], [520, { x: 3 * k }, SNAP], [620, {}]] });
    if (P.copy) s.drag(P.copy, { c: B, grab: [.3, .2], frame: 'move', pad: 0, keys: [[300, { x: 30 * k, y: 40 * k }, DRAG], [740, { y: -3 * k }, SNAP], [840, {}]] });
    if (P.desk && P.shots) {
      // Отступ слева у скриншота сначала больше нужного: курсор подвигает картинку, заштрихованный отступ сужается
      const S = s.rel(P.shots), Dk = within(s, P.desk, P.shots), gap = Math.max(4, Dk.x - S.x), dx = 18 * k;
      s.drag(P.desk, { c: A, grab: [.06, .5], box: Dk, frame: 'media', pad: 0, appear: false, keys: [[720, { x: dx }, DRAG], [980, { x: -2 * k }, SNAP], [1060, {}]] });
      s.tint([[720, { x: S.x, y: Dk.y, w: gap + dx, h: Dk.h * .7 }, DRAG], [980, { x: S.x, y: Dk.y, w: gap - 2 * k, h: Dk.h * .7 }, SNAP], [1060, { x: S.x, y: Dk.y, w: gap, h: Dk.h * .7 }]], 'media', 680, 1100);
    }
    if (P.more) s.drag(P.more, { c: B, grab: [.5, .5], frame: 'move', pad: 4, keys: [[960, { y: 20 * k }, DRAG], [1200, { y: -2 * k }, SNAP], [1280, {}]] });
    A.exit(1120); B.exit(1340);
  }

  // «Есть задача?»: заголовок быстро набирается, второй курсор растягивает кнопку на всю ширину
  function cardAsk(s, card, { k }) {
    const P = parts(card), A = s.cursor('size'), B = s.cursor('text');
    s.show(card, 0, { dur: 260, y: 10 * k });
    if (P.client) s.show(P.client, 140, { x: -8 * k });
    if (P.title) s.type(P.title, null, { c: B, t0: 220, t1: 680 });
    if (P.more) s.crop(P.more, { c: A, handle: 'r', frame: 'size', pad: 4, round: '999px', keys: [
      [340, [0, .74, 0, 0], DRAG], [720, [0, .06, 0, 0], 'linear'], [800, [0, .06, 0, 0], SNAP], [900, [0, 0, 0, 0]]
    ] });
    A.exit(960); B.exit(900);
  }

  const CARDS = { 'edu-app': cardPull, mep: cardStretch, prokat: cardCrop, banket: cardTilt, 'phone-shop': cardSplit };
  const cardScene = (slug, i) => !slug ? cardAsk : CARDS[slug] || [cardPull, cardStretch, cardCrop, cardTilt, cardSplit][i % 5];

  // «Обо мне»: один курсор чертит текстовое поле и подправляет ширину, другой открывает текст группами строк
  function lead(s, el, { k }) {
    const A = s.cursor('size'), B = s.cursor('text');
    const L = s.rel(el), pad = 10;
    const n = s.lineBoxes(el).length;
    s.marquee({ x: L.x - pad, y: L.y - pad, w: L.w + pad * 2, h: L.h + pad * 2 }, { c: A, role: 'size', t0: 140, t1: 520, over: 34 * k, fix: [660, 900], until: 1500 });
    s.lines(el, { c: B, t0: 400, t1: 1380, per: Math.max(1, Math.ceil(n / 4)) });
    A.exit(980); B.exit(1440);
  }

  // Факты: у каждого своё действие с маленькой поправкой
  const facts = [
    (s, el, { k }) => {
      const c = s.cursor('move');
      s.drag(el, { c, grab: [.15, .3], frame: 'move', keys: [[100, { y: 34 * k }, DRAG], [460, { y: -4 * k }, SNAP], [560, {}]] });
      c.exit(660);
    },
    (s, el) => {
      const c = s.cursor('size');
      s.crop(el, { c, handle: 'tr', frame: 'size', pad: 2, keys: [[100, [0, 1, 0, 0], WIPE], [460, [0, .14, 0, 0], 'linear'], [540, [0, .14, 0, 0], SNAP], [700, [0, 0, 0, 0]]] });
      c.exit(780);
    },
    (s, el, { k }) => {
      const c = s.cursor('text'), dt = $('dt', el), dd = $('dd', el);
      s.show(el, 40, { dur: 160 });
      if (dt) s.show(dt, 100, { x: -12 * k });
      if (dd) s.type(dd, null, { c, t0: 280, t1: 740 });
      c.exit(860);
    }
  ];

  // Строки навыков: перенос к направляющей, набор и ширина описания, открытие слева направо
  function row(i) {
    const dir = i < 3 ? 1 : -1;
    const v = i % 3;
    if (v === 0) return (s, el, { k }) => {
      const h = $('h3', el), p = $('p', el), c = s.cursor('move');
      const R = s.rel(el), H = textBox(s, h);
      s.show(el, 0, { dur: 160 });
      s.drag(h, { c, grab: [.04, .5], box: H, frame: 'move', keys: [[120, { x: 70 * k * dir }, DRAG], [480, { x: -5 * k * dir }, SNAP], [580, {}]] });
      s.guide({ x: H.x, y: R.y, w: 0, h: R.h }, 400, 780, 'move');
      if (p) s.show(p, 340, { y: 10 * k, dur: 320 });
      c.exit(720);
    };
    if (v === 1) return (s, el) => {
      const h = $('h3', el), p = $('p', el), t = s.cursor('text'), z = s.cursor('size');
      s.show(el, 0, { dur: 160 });
      s.type(h, null, { c: t, t0: 160, t1: 600 });
      if (p) s.crop(p, { c: z, handle: 'r', frame: 'size', pad: 4, keys: [[300, [0, .62, 0, 0], DRAG], [640, [0, .1, 0, 0], 'linear'], [700, [0, .1, 0, 0], SNAP], [820, [0, 0, 0, 0]]] });
      t.exit(860); z.exit(900);
    };
    return (s, el, { k }) => {
      const p = $('p', el), z = s.cursor('size');
      s.crop(el, { c: z, handle: dir > 0 ? 'r' : 'l', keys: [[100, dir > 0 ? [0, 1, 0, 0] : [0, 0, 0, 1], WIPE], [500, [0, 0, 0, 0]]] });
      // Ширина описания: рамка сначала шире текста, курсор доводит её до края текста
      if (p) {
        const T = textBox(s, p), box = { x: T.x - 6, y: T.y - 6, w: T.w + 12, h: T.h + 12 };
        s.marquee(box, { c: z, role: 'size', t0: 640, t1: 900, from: [1 + 44 * k / box.w, 1], until: 1040 });
      }
      z.exit(1000);
    };
  }

  // Технологии и ИИ-инструменты: заголовок набирается, подписи и значения строк встают параллельно,
  // первая подпись ставится к направляющей, одна из следующих поправляется
  function tools(s, el, { k }) {
    const title = $('.tools__title', el), rows = $$('.tools__list > div', el);
    const T = s.cursor('text'), M = s.cursor('move');
    if (title) s.type(title, null, { c: T, t0: 160, t1: 160 + clamp(title.textContent.length * 30, 260, 520) });
    T.exit(860);
    if (!rows.length) return;
    const first = $('dt', rows[0]), G = first ? s.rel(first) : s.rel(rows[0]), last = s.rel(rows[rows.length - 1]);
    const fix = rows.length >= 4 ? 2 : -1;
    rows.forEach((r, i) => {
      const dt = $('dt', r), dd = $('dd', r), t = 260 + i * 130;
      s.show(r, t - 40, { dur: 140 });
      if (dt && i === 0) s.drag(dt, { c: M, grab: [.1, .5], frame: 'move', keys: [[t, { x: -46 * k }, DRAG], [t + 360, { x: 4 * k }, SNAP], [t + 450, {}]] });
      else if (dt && i === fix) s.drag(dt, { frame: 'move', moves: [
        { c: null, keys: [[t, { x: -30 * k }, DRAG], [t + 360, { x: 12 * k }]] },
        { c: M, grab: [.1, .5], keys: [[t + 640, { x: 12 * k }, SNAP], [t + 860, { x: -2 * k }, SNAP], [t + 940, {}]] }
      ] });
      else if (dt) s.show(dt, t, { x: -30 * k, dur: 380, e: DRAG });
      if (dd) s.show(dd, t + 70, { x: 30 * k, dur: 400, e: DRAG });
    });
    s.guide({ x: G.x, y: G.y - 12, w: 0, h: last.y + last.h - G.y + 12 }, 560, fix > 0 ? 1640 : 900, 'move');
    M.exit(fix > 0 ? 1640 : 900);
  }

  // Шаги: номер, заголовок и описание делают разные курсоры
  function step(i) {
    return (s, el, { k }) => {
      const n = $('.step__n', el), h = $('h3', el), p = $('p', el);
      const A = s.cursor(i % 2 ? 'size' : 'move'), B = s.cursor('text');
      const N = n && textBox(s, n);
      s.show(el, 0, { dur: 160 });
      if (n && i % 2 === 0) s.drag(n, { c: A, grab: [.5, .5], box: N, frame: 'move', pad: 5, keys: [[120, { y: -22 * k }, DRAG], [420, { y: 3 * k }, SNAP], [500, {}]] });
      else if (n) s.drag(n, { c: A, grab: [1, 1], origin: [0, 0], box: N, frame: 'size', pad: 5, keys: [[120, { s: .5 }, DRAG], [400, { s: 1.15 }, SNAP], [500, {}]] });
      if (h) s.type(h, null, { c: B, t0: 260, t1: 260 + clamp(h.textContent.length * 26, 240, 480) });
      if (p) s.lines(p, { c: A, t0: 620, t1: 1120, per: 2, role: A.real ? A.role : 'text' });
      A.exit(1180); B.exit(900);
    };
  }

  // Подпись у контактов: строки открываются выделением
  function note(s, el) {
    const c = s.cursor('text');
    s.lines(el, { c, t0: 140, t1: 560 });
    c.exit(680);
  }

  // Контакты: у каждого своё короткое действие; на сами ссылки курсоры не нажимают
  const links = [
    (s, el, { k }) => {
      const nm = $('.biglink__name', el), hd = $('.biglink__handle', el), c = s.cursor('text');
      s.show(el, 0, { dur: 160 });
      if (nm) s.type(nm, null, { c, t0: 160, t1: 520 });
      if (hd) s.show(hd, 420, { x: 28 * k, dur: 360, e: DRAG });
      c.exit(720);
    },
    (s, el) => {
      const hd = $('.biglink__handle', el), c = s.cursor('size');
      s.crop(el, { c, handle: 'tr', keys: [[100, [0, 1, 0, 0], WIPE], [560, [0, 0, 0, 0]]] });
      if (hd) s.pop(hd, 500, { origin: '100% 50%' });
      c.exit(700);
    },
    (s, el, { k }) => {
      const nm = $('.biglink__name', el), hd = $('.biglink__handle', el), c = s.cursor('move');
      s.show(el, 0, { dur: 160 });
      if (nm) s.drag(nm, { c, grab: [.2, .5], frame: 'move', keys: [[120, { x: 56 * k }, DRAG], [500, { x: -5 * k }, SNAP], [600, {}]] });
      if (hd) s.show(hd, 380, { y: 10 * k });
      c.exit(720);
    }
  ];

  /* ---------- Сцены кейса ---------- */

  const typeTime = (el, per, a, b) => clamp(el.textContent.trim().length * per, a, b);

  // Шапка: клиент и название набираются, поле описания чертят и открывают строками, сведения и кнопку ставят
  function caseHead(s, el, { k }) {
    const cl = $('.case__client', el), ti = $('.case__title', el), le = $('.case__lead', el);
    const me = $('.case__meta', el), ln = $('.case__link', el);
    const T = s.cursor('text'), Z = s.cursor('size'), M = s.cursor('move');
    let t = 140;
    if (cl) { s.type(cl, null, { c: T, t0: t, t1: t + typeTime(cl, 16, 220, 420), pad: 4 }); t += typeTime(cl, 16, 220, 420) + 100; }
    if (ti) { const r = s.type(ti, '.ln > span', { c: T, t0: t, t1: t + typeTime(ti, 22, 520, 1000), pad: 8 }); T.exit(r.end - 40, { x: 30 * k, y: -24 * k }); }
    if (le) {
      const L = textBox(s, le), pad = 10, n = s.lineBoxes(le).length, t1 = 1080 + clamp(n * 150, 400, 900);
      s.marquee({ x: L.x - pad, y: L.y - pad, w: L.w + pad * 2, h: L.h + pad * 2 }, { c: Z, role: 'size', t0: 320, t1: 700, over: 34 * k, fix: [820, 1020], until: t1 + 120 });
      s.lines(le, { c: Z, t0: 1080, t1, per: Math.max(1, Math.ceil(n / 4)), role: Z.real ? Z.role : 'text' });
      Z.exit(t1 + 80);
    }
    if (me) {
      const R = s.rel(me);
      s.drag(me, { c: M, grab: [.08, .2], frame: 'move', pad: 4, keys: [[420, { x: 70 * k }, DRAG], [820, { x: -5 * k }, SNAP], [920, {}]] });
      $$(':scope > div', me).forEach((d, i) => s.show(d, 520 + i * 110, { y: 8 * k, dur: 260 }));
      s.guide({ x: R.x, y: R.y - 12, w: 0, h: R.h + 24 }, 760, 1060, 'move');
    }
    if (ln) s.drag(ln, { c: M, grab: [.5, .5], frame: 'move', pad: 4, keys: [[1080, { y: 22 * k }, DRAG], [1320, { y: -2 * k }, SNAP], [1400, {}]] });
    M.exit(1460);
  }

  // Обложка открывается расширяющимся кадром из середины
  function caseCover(s, el) {
    const Z = s.cursor('size');
    s.crop(el, { c: Z, handle: 'br', frame: 'size', round: radius(el), keys: [[120, [.3, .32, .3, .32], DRAG], [660, [0, .02, 0, 0], 'linear'], [720, [0, .02, 0, 0], SNAP], [840, [0, 0, 0, 0]]] });
    Z.exit(920);
  }

  // Было → стало крупными цифрами: первое число ставят на место, стрелку протягивают, второе растягивают за угол
  function numPair(s, el, { k }) {
    const [a, b] = $$('.nums__side', el), ar = $('.nums__arrow', el);
    const A = s.cursor('move'), B = s.cursor('size');
    const an = a && $('.nums__n', a), al = a && $('.nums__l', a), bn = b && $('.nums__n', b), bl = b && $('.nums__l', b);
    if (an) s.drag(an, { c: A, grab: [.35, .5], box: textBox(s, an), frame: 'move', pad: 6, keys: [[100, { y: 46 * k }, DRAG], [480, { y: -4 * k }, SNAP], [580, {}]] });
    if (al) s.lines(al, { c: A, t0: 660, t1: 940, role: A.real ? A.role : 'text' });
    if (ar) s.crop(ar, { c: B, handle: 'r', keys: [[300, [0, 1, 0, 0], WIPE], [640, [0, 0, 0, 0]]] });
    if (bn) s.drag(bn, { c: B, grab: [1, 1], origin: [0, 1], box: textBox(s, bn), frame: 'size', pad: 6, keys: [[740, { s: .6 }, DRAG], [1040, { s: 1.06 }, SNAP], [1140, {}]] });
    if (bl) s.lines(bl, { t0: 1080, t1: 1320, sweep: false });
    A.exit(1000); B.exit(1220);
  }

  // Факт: число и подпись, у каждого факта своё действие
  const caseFacts = [
    (s, el, { k }) => {
      const v = $('b', el), l = $('span', el), c = s.cursor('move');
      s.crop(el, { keys: [[60, [0, 1, 0, 0], WIPE], [520, [0, 0, 0, 0]]] });
      if (v) s.drag(v, { c, grab: [.3, .5], frame: 'move', pad: 4, keys: [[160, { x: -44 * k }, DRAG], [520, { x: 4 * k }, SNAP], [600, {}]] });
      if (l) s.show(l, 420, { x: 20 * k, dur: 340, e: DRAG });
      c.exit(700);
    },
    (s, el, { k }) => {
      const l = $('span', el), c = s.cursor('size');
      s.crop(el, { c, handle: 'tr', frame: 'size', pad: 2, keys: [[100, [0, 1, 0, 0], WIPE], [460, [0, .12, 0, 0], 'linear'], [540, [0, .12, 0, 0], SNAP], [700, [0, 0, 0, 0]]] });
      if (l) s.show(l, 380, { y: 8 * k });
      c.exit(780);
    },
    (s, el, { k }) => {
      const v = $('b', el), l = $('span', el), c = s.cursor('text');
      s.show(el, 0, { dur: 160 });
      if (v) s.type(v, null, { c, t0: 160, t1: 160 + typeTime(v, 60, 200, 420), pad: 4 });
      if (l) s.show(l, 480, { x: 24 * k, dur: 360, e: DRAG });
      c.exit(820);
    }
  ];

  // Задача и решение: подпись набирается, поле абзаца чертят, текст открывается строками
  function duo(s, el, { k }) {
    const lb = $('.label', el), p = $('p:not(.label)', el);
    const Z = s.cursor('size'), T = s.cursor('text');
    if (lb) s.type(lb, null, { c: T, t0: 120, t1: 120 + typeTime(lb, 24, 200, 380), pad: 4 });
    if (!p) { T.exit(620); Z.exit(0); return; }
    const P = textBox(s, p), pad = 10, n = s.lineBoxes(p).length, t1 = 660 + clamp(n * 160, 400, 1100);
    s.marquee({ x: P.x - pad, y: P.y - pad, w: P.w + pad * 2, h: P.h + pad * 2 }, { c: Z, role: 'size', t0: 220, t1: 560, over: 30 * k, fix: [680, 880], until: t1 + 100 });
    s.lines(p, { c: T, t0: 660, t1, per: Math.max(1, Math.ceil(n / 4)) });
    Z.exit(940); T.exit(t1 + 60);
  }

  // Четыре ресурса → одно приложение: старые плитки раскладывают, стрелку протягивают, новую плитку ставят и подписывают.
  // У старых плиток в CSS свой наклон и сдвиг, поэтому их проявляют масштабом; тянут только первую, у неё сдвига нет
  function merge(s, el, { k }) {
    const labels = $$('.label', el), from = $$('.merge__from .tile', el), mid = $('.merge__mid', el), to = $('.tile--to', el);
    const A = s.cursor('move'), B = s.cursor('media');
    labels.forEach((l, i) => s.show(l, 60 + i * 620, { x: -10 * k }));
    from.forEach((t, i) => {
      if (i === 0) s.drag(t, { c: A, grab: [.3, .3], frame: 'move', pad: 4, keys: [[160, { x: -40 * k, y: -24 * k }, DRAG], [520, { x: 3 * k }, SNAP], [600, {}]] });
      else s.pop(t, 260 + i * 120, { from: .86 });
    });
    if (mid) s.crop(mid, { keys: [[600, [0, 1, 0, 0], WIPE], [900, [0, 0, 0, 0]]] });
    if (to) {
      s.drag(to, { c: B, grab: [.5, .5], frame: 'media', pad: 4, keys: [[760, { x: 60 * k }, DRAG], [1120, { x: -4 * k }, SNAP], [1200, {}]] });
      const b = $('b', to), sp = $('span', to);
      if (b) s.type(b, null, { c: B, t0: 1280, t1: 1280 + typeTime(b, 30, 240, 480), pad: 4 });
      if (sp) s.show(sp, 1500, { y: 8 * k });
    }
    A.exit(720); B.exit(1840);
  }

  // Списки: заголовок набирают или переносят, пункты открываются строками
  function listBlock(i) {
    const v = i % 3;
    return (s, el, { k }) => {
      const h = $('h3', el), ul = $('ul', el);
      const n = ul ? s.lineBoxes(ul).length : 0, per = Math.max(1, Math.ceil(n / 5));
      if (v === 0) {
        const c = s.cursor('text');
        let t = 140;
        if (h) { s.type(h, null, { c, t0: t, t1: t + typeTime(h, 26, 220, 460), pad: 4 }); t += typeTime(h, 26, 220, 460) + 160; }
        if (ul) s.lines(ul, { c, t0: t, t1: t + clamp(n * 120, 360, 900), per });
        c.exit(t + clamp(n * 120, 360, 900) + 60);
      } else if (v === 1) {
        const c = s.cursor('size');
        if (h) s.show(h, 60, { x: -16 * k, dur: 300, e: DRAG });
        if (ul) s.crop(ul, { c, handle: 'b', frame: 'size', pad: 2, keys: [[200, [0, 0, .9, 0], DRAG], [620, [0, 0, .08, 0], 'linear'], [700, [0, 0, .08, 0], SNAP], [820, [0, 0, 0, 0]]] });
        c.exit(900);
      } else {
        const c = s.cursor('move');
        if (h) s.drag(h, { c, grab: [.08, .5], box: textBox(s, h), frame: 'move', pad: 4, keys: [[120, { x: -60 * k }, DRAG], [480, { x: 5 * k }, SNAP], [560, {}]] });
        if (ul) s.lines(ul, { t0: 520, t1: 520 + clamp(n * 110, 320, 820), per, role: 'move' });
        c.exit(640);
      }
    };
  }

  // Подзаголовок кейса набирается
  function caseSub(s, el, { k }) {
    const c = s.cursor('text');
    const r = s.type(el, null, { c, t0: 200, t1: 200 + typeTime(el, 28, 260, 520), pad: 6 });
    c.exit(r.end - 60, { x: 30 * k, y: -24 * k });
  }

  // Ряд экранов: широкий открывают кадром или ставят переносом, телефонный подносят сбоку, подписи открываются строками
  function gallery(i) {
    return (s, row, { k }) => {
      const figs = $$('figure', row);
      const wide = figs.find(f => !f.classList.contains('is-phone')), phone = figs.find(f => f.classList.contains('is-phone'));
      const A = s.cursor('media'), B = s.cursor('size');
      const W = wide && s.rel(wide), P = phone && s.rel(phone);
      const dir = W && P && P.x + P.w / 2 < W.x + W.w / 2 ? -1 : 1;     // с какой стороны стоит телефон
      const tw = 100;
      let tp = 420;
      if (wide) {
        const im = $('img', wide);
        if (i % 2 === 0 && im) s.crop(im, { c: B, handle: 'br', frame: 'size', round: radius(im), keys: [[tw, [.3, .34, .3, .34], DRAG], [620, [0, 0, 0, 0]]] });
        else s.drag(wide, { c: A, grab: [.4, .3], frame: 'media', pad: 4, keys: [[tw, { x: -dir * 50 * k, y: 26 * k }, DRAG], [520, { x: dir * 3 * k }, SNAP], [620, {}]] });
      }
      if (phone) {
        if (i % 2 === 0) s.drag(phone, { c: A, grab: [.5, .3], frame: 'media', pad: 4, keys: [[tp, { x: dir * 56 * k, y: 30 * k }, DRAG], [800, { x: -dir * 3 * k }, SNAP], [900, {}]] });
        else {
          s.drag(phone, { c: B, grab: [1, 1], origin: [0, 0], frame: 'size', pad: 4, keys: [[tp, { s: .72 }, DRAG], [760, { s: 1.04 }, SNAP], [860, {}]] });
          tp += 40;
        }
      }
      figs.forEach(f => {
        const cap = $('figcaption', f);
        if (cap) s.lines(cap, { t0: (f === phone ? tp : tw) + 520, t1: (f === phone ? tp : tw) + 800, role: 'media' });
      });
      A.exit(1000); B.exit(1000);
    };
  }

  // Финал: вопрос набирается, кнопки ставят
  function caseEnd(s, el, { k }) {
    const h = $('h3', el), btns = $$('.btn', el);
    const T = s.cursor('text'), M = s.cursor('media');
    let end = 600;
    if (h) { const r = s.type(h, null, { c: T, t0: 160, t1: 160 + typeTime(h, 26, 320, 620), pad: 6 }); end = r.end; T.exit(end - 60); }
    btns.forEach((b, i) => {
      const t = 520 + i * 260;
      if (i === 0) s.drag(b, { c: M, grab: [.5, .5], frame: 'media', pad: 4, keys: [[t, { y: 24 * k }, DRAG], [t + 260, { y: -2 * k }, SNAP], [t + 340, {}]] });
      else s.pop(b, t, { origin: '0% 50%' });
    });
    M.exit(520 + btns.length * 260 + 140);
  }

  /* ---------- Список блоков ---------- */

  // Элементы ищутся при каждой проверке: смена языка перерисовывает карточки
  function collect() {
    const out = [];
    const put = (id, el, build, want = 1) => { if (el) out.push({ id, el, build, want }); };
    put('works:title', $('#works-title'), heading);
    $$('#works-grid > .card').forEach((card, i) => put('card:' + (card.dataset.slug || 'cta'), card, cardScene(card.dataset.slug, i), 2));
    put('about:title', $('#about-title'), heading);
    put('about:lead', $('#about-lead'), lead, 2);
    $$('#about .facts > div').forEach((el, i) => put('about:fact' + (i + 1), el, facts[i % 3]));
    put('skills:title', $('#skills-title'), heading);
    $$('#skills .rows > .row').forEach((el, i) => put('skills:row' + (i + 1), el, row(i), i % 3 === 1 ? 2 : 1));
    $$('#skills .tools').forEach((el, i) => put(el.classList.contains('tools--ai') ? 'skills:ai' : 'skills:tech' + (i || ''), el, tools, 2));
    put('process:title', $('#process-title'), heading);
    $$('#process .steps__list > .step').forEach((el, i) => put('process:step' + (i + 1), el, step(i), 2));
    put('contacts:title', $('#contacts-title'), heading);
    put('contacts:note', $('#contacts .sec__note'), note);
    $$('#contacts .biglink').forEach((el, i) => put('contacts:link' + (i + 1), el, links[i % 3]));
    return out;
  }

  // Блоки открытого кейса. Каждое открытие кейса — новый набор id: кейс собирается при каждом входе,
  // а внутри одного открытия показанные блоки не пересобираются
  const caseEl = $('#case'), caseScroll = $('#case-scroll'), caseBody = $('#case-body');
  let caseOn = 0, caseN = 0;
  function collectCase() {
    const out = [];
    if (!caseOn || !caseBody) return out;
    const put = (id, el, build, want = 1) => { if (el) out.push({ id: 'case' + caseOn + ':' + id, el, build, want, temp: true }); };
    put('head', $('.case__head', caseBody), caseHead, 3);
    put('cover', $('.case__cover', caseBody), caseCover);
    $$('.nums__pair', caseBody).forEach((el, i) => put('num' + (i + 1), el, numPair, 2));
    $$('.nums > .fact', caseBody).forEach((el, i) => put('fact' + (i + 1), el, caseFacts[i % 3]));
    $$('.duo > div', caseBody).forEach((el, i) => put('duo' + (i + 1), el, duo, 2));
    put('merge', $('.merge', caseBody), merge, 2);
    $$('.lists > div', caseBody).forEach((el, i) => put('list' + (i + 1), el, listBlock(i)));
    put('shots', $('#shots-title', caseBody), caseSub);
    $$('.shots .gallery', caseBody).forEach((el, i) => put('row' + (i + 1), el, gallery(i), 2));
    put('end', $('.case__end', caseBody), caseEnd, 2);
    return out;
  }

  /* Поле — где идут сцены: сама страница или открытый кейс со своей прокруткой. У поля свой список блоков,
     своя скорость прокрутки и своя пауза; лимит курсоров общий */
  const page = { collect, top: () => scrollY, samples: [], pauseUntil: 0, lastFast: -1e9,
    on: () => !root.classList.contains('is-locked') };      // открыт кейс: страница под ним стоит
  const inCase = { collect: collectCase, top: () => caseScroll.scrollTop, samples: [], pauseUntil: 0, lastFast: -1e9,
    on: () => !!caseOn };
  const fields = caseScroll && caseBody ? [page, inCase] : [page];

  /* ---------- Состояния ---------- */

  const ARM = 2.2;         // за сколько высот окна до появления блок готовится
  const HIDE = 12000;      // мс: столько держится скрытие подготовленного блока; пока блок ждёт, оно обновляется
  const FAST = 2000;       // px/с: быстрее — блоки в окне не стартуют
  const STAGGER = 230;     // мс между стартами соседних блоков
  const WAIT = 900;        // мс: дольше без свободного курсора — сцена идёт без него

  const units = new Map();
  // temp — блок кейса: в сессии не запоминается
  const state = (id, temp) => { let st = units.get(id); if (!st) units.set(id, st = { id, s: saved.has(id) ? 'done' : 'idle', hides: [], temp }); return st; };
  const budget = () => innerWidth >= 900 ? 5 : innerWidth >= 640 ? 3 : 2;
  const maxRunning = () => innerWidth >= 900 ? 5 : 3;
  let used = 0, busy = 0, lastStart = -1e9, started = false;

  // Вместе с блоком — его обёртки и части с собственным появлением (.rv из js/app.js): сцена ставит их сама.
  // CSS-переходы на время сцены выключены, иначе после снятия анимаций блок проявился бы ещё раз
  function heldOf(el) {
    const out = new Set([el]);
    for (let p = el.parentElement; p && !p.classList.contains('sec') && p !== caseBody; p = p.parentElement) if (p.classList.contains('rv')) out.add(p);
    $$('.rv, .rv-line, .rv-line > span', el).forEach(x => out.add(x));
    return [...out];
  }
  function hold(list) {
    list.forEach(x => {
      x.style.transition = 'none';
      if (x.matches('.rv, .rv-line')) x.classList.add('is-in');
    });
  }
  function letGo(list) {
    if (!list) return;
    const reset = () => list.forEach(x => { x.style.transition = ''; });
    requestAnimationFrame(() => requestAnimationFrame(reset));
    setTimeout(reset, 400);            // в фоновой вкладке кадров нет: переходы всё равно вернём
  }
  const hideAnim = el => el.animate([{ opacity: 0 }, { opacity: 0 }], { duration: HIDE });

  function arm(u, st, now) {
    st.el = u.el;
    st.held = heldOf(u.el);
    hold(st.held);
    st.hides = [hideAnim(u.el)];
    st.at = now;
    st.s = 'armed';
  }
  // Скрытие обновляется заранее: блок, который долго ждёт ниже окна, не проявится сам
  function renew(st, now) {
    const old = st.hides;
    st.hides = [hideAnim(st.el)];
    old.forEach(a => a.cancel());
    st.at = now;
  }
  function disarm(st) {
    st.hides.forEach(a => a.cancel());
    st.hides = [];
    letGo(st.held);
    st.held = null; st.el = null;
    st.s = 'idle';
  }
  function markDone(st) {
    st.s = 'done';
    if (test || st.temp) return;       // проверочный запуск и кейс ничего не запоминают
    saved.add(st.id);
    save();
  }
  // Готов без сцены. soft — блок в окне: короткое проявление вместо скачка
  function reveal(st, soft) {
    const el = st.el;
    st.hides.forEach(a => a.cancel());
    st.hides = [];
    letGo(st.held);
    if (soft && el && el.animate) el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 220, easing: 'ease-out' });
    markDone(st);
  }
  function freeCursors(st) { used -= st.grant || 0; st.grant = 0; }
  function unqueue(st) {
    clearTimeout(st.timer);
    freeCursors(st);
    busy--;
    st.s = 'armed';
  }

  function queue(u, st, delay, grant, short) {
    st.s = 'queued';
    st.grant = grant;
    used += grant;
    busy++;
    st.timer = setTimeout(() => begin(u, st, short), delay);
  }

  function begin(u, st, short) {
    st.timer = 0;
    if (st.s !== 'queued') return;
    if (!u.el.isConnected || st.el !== u.el) { unqueue(st); disarm(st); return; }
    const host = u.el.closest('.sec, .case__body') || document.body;
    const narrow = innerWidth < 900;
    let s = null, total = 0;
    try {
      s = Kit.stage(host, { tempo: (short ? .7 : 1) * Kit.slow, cursors: st.grant });
      u.build(s, u.el, { k: narrow ? .6 : 1, narrow });
      total = s.commit();
    } catch (e) {
      if (s) s.cancel();
      if (Kit.dev) console.warn('scene', u.id, e);
      unqueue(st); reveal(st, true);
      return;
    }
    // Скрытие снимаем в той же задаче, в которой встали анимации сцены: мигания нет
    st.hides.forEach(a => a.cancel());
    st.hides = [];
    st.s = 'running';
    st.stage = s;
    Scenes.running = true;
    if (test && test[1] === u.id && seekM) { s.seek(+seekM[1]); return; }
    if (Kit.stepMode) return;
    st.free = setTimeout(() => freeCursors(st), s.cursorEnd * s.tempo + 40);
    st.timer = setTimeout(() => finish(st), total + 80);
  }

  function finish(st) {
    if (st.s !== 'running') return;
    clearTimeout(st.timer); clearTimeout(st.free);
    st.stage.cancel();
    st.stage = null;
    letGo(st.held);
    freeCursors(st);
    busy--;
    markDone(st);
    Scenes.running = [...units.values()].some(x => x.s === 'running');
    soon(0);
  }

  // Соседи по ряду стартуют со сдвигом, следующий блок — не раньше чем через 180 мс после предыдущего
  function schedule(list, now, f) {
    list.sort((a, b) => (a[2].top - b[2].top) || (a[2].left - b[2].left));
    const short = now - f.lastFast < 500;
    let slot = 0;
    for (const [u, st] of list) {
      if (busy >= maxRunning()) { soon(200); break; }
      const grant = Math.min(u.want, Math.max(0, budget() - used));
      if (u.want && !grant) {
        st.waitSince = st.waitSince || now;
        if (now - st.waitSince < WAIT) { soon(200); continue; }
      }
      st.waitSince = 0;
      const at = Math.max(now + slot * STAGGER, lastStart + 180);
      lastStart = at;
      slot++;
      queue(u, st, at - now, grant, short);
    }
  }

  /* ---------- Проверка ---------- */

  function check() {
    if (!started || test) return;
    fields.forEach(look);
  }
  function look(f) {
    if (!f.on()) return;
    const now = performance.now();
    if (now < f.pauseUntil) { soon(f.pauseUntil - now + 20); return; }
    const vh = innerHeight, fast = speed(f) > FAST;
    if (fast) f.lastFast = now;
    const ready = [];
    f.collect().forEach(u => {
      const st = state(u.id, u.temp);
      if (st.s === 'done') return;
      if (st.el && st.el !== u.el) {                            // блок перерисован
        if (st.s === 'running') { finish(st); return; }
        if (st.s === 'queued') unqueue(st);
        disarm(st);
      }
      const r = u.el.getBoundingClientRect();
      const inView = r.bottom > 0 && r.top < vh;
      if (st.s === 'running') {                                 // блок ушёл из окна: сцену заканчиваем
        if (r.bottom < -60 || r.top > vh + 60) finish(st);
        return;
      }
      if (st.s === 'queued') { if (inView) return; unqueue(st); }
      if (st.s === 'idle') {
        // Уже в окне или выше, а подготовки не было (страница открыта посередине, прыжок прокрутки): как есть
        if (r.top < vh) { markDone(st); return; }
        if (r.top < vh * ARM) arm(u, st, now);
        return;
      }
      // armed
      if (now - st.at > HIDE - 4000) renew(st, now);
      if (r.bottom <= 0) { reveal(st, false); return; }          // пролистан
      if (r.top > vh * (ARM + 1)) { disarm(st); return; }        // снова далеко внизу
      if (!inView) { st.fastSince = 0; return; }
      if (fast) {
        // Пролёт: ждём остановки, но долго пустым блок не держим
        st.fastSince = st.fastSince || now;
        if (now - st.fastSince > 650) reveal(st, true);
        return;
      }
      st.fastSince = 0;
      const visible = Math.min(r.bottom, vh) - Math.max(r.top, 0);
      if (r.top < vh * .86 && visible >= Math.min(r.height * .35, vh * .3)) ready.push([u, st, r]);
      else if (r.top < 0) reveal(st, true);                      // остановились, когда блок почти пролистан
    });
    if (ready.length) schedule(ready, now, f);
  }

  /* ---------- Прокрутка: скорость по последним 160 мс ---------- */

  function sample(f) {
    const t = performance.now(), samples = f.samples;
    samples.push([t, f.top()]);
    while (samples.length > 2 && t - samples[0][0] > 160) samples.shift();
  }
  function speed(f) {
    const samples = f.samples, n = samples.length;
    if (n < 2) return 0;
    const a = samples[0], b = samples[n - 1];
    if (performance.now() - b[0] > 140) return 0;              // прокрутка остановилась
    return Math.abs(b[1] - a[1]) / Math.max(b[0] - a[0], 16) * 1000;
  }

  let raf = 0, tmo = 0, settle = 0;
  function run() { cancelAnimationFrame(raf); clearTimeout(tmo); raf = tmo = 0; check(); }
  // Проверка в ближайшем кадре; в фоновой вкладке кадров нет — тогда по таймеру
  function soon(ms) {
    if (ms > 0) { setTimeout(() => soon(0), ms); return; }
    if (!raf) raf = requestAnimationFrame(run);
    if (!tmo) tmo = setTimeout(run, 120);
  }

  const onScroll = f => () => {
    sample(f);
    soon(0);
    clearTimeout(settle);
    settle = setTimeout(run, 170);                            // после остановки скорость гаснет — ещё одна проверка
  };
  addEventListener('scroll', onScroll(page), { passive: true });
  if (caseScroll) caseScroll.addEventListener('scroll', onScroll(inCase), { passive: true });

  // На телефоне адресная строка при прокрутке меняет только высоту окна — это не повод прерывать сцены
  let lastW = innerWidth;
  addEventListener('resize', () => {
    if (innerWidth !== lastW) {
      lastW = innerWidth;
      units.forEach(st => { if (st.s === 'running') finish(st); else if (st.s === 'queued') unqueue(st); });
    }
    soon(0);
  }, { passive: true });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) soon(0); });

  // Нажатие или фокус внутри блока: блок сразу готов, само действие выполняется как обычно
  const touch = e => {
    const t = e.target;
    if (!t || !t.nodeType) return;
    units.forEach(st => {
      if (!st.el || !st.el.contains(t)) return;
      if (st.s === 'running') finish(st);
      else if (st.s === 'queued') { unqueue(st); reveal(st, false); }
      else if (st.s === 'armed') reveal(st, false);
    });
  };
  addEventListener('pointerdown', touch, { capture: true, passive: true });
  addEventListener('focusin', touch, true);

  /* ---------- Управление снаружи ---------- */

  Scenes.finish = () => { units.forEach(st => { if (st.s === 'running') finish(st); }); };
  // Смена языка (js/i18n.js): идущие сцены завершаются, подготовка снимается — не показанные блоки
  // не считаются показанными и соберутся позже, уже на новом языке
  Scenes.releaseAll = () => {
    fields.forEach(f => { f.pauseUntil = performance.now() + 450; });
    units.forEach(st => {
      if (st.s === 'running') finish(st);
      else if (st.s === 'queued') { unqueue(st); disarm(st); }
      else if (st.s === 'armed') disarm(st);
    });
    soon(470);
  };
  Scenes.debug = () => {
    const out = {};
    units.forEach((st, id) => { out[id] = st.s; });
    return { units: out, cursors: used, running: busy, speed: Math.round(speed(page)), caseSpeed: Math.round(speed(inCase)) };
  };
  Scenes.seek = ms => units.forEach(st => { if (st.stage) st.stage.seek(ms); });

  // Кейс открыт (js/app.js): блоки в окне и чуть ниже сразу прячутся до сборки, шапка стартует,
  // когда кейс проявится. Блоки ниже соберутся при прокрутке кейса
  function caseOpen() {
    caseClose();
    caseOn = ++caseN;
    const now = performance.now(), vh = innerHeight;
    inCase.pauseUntil = now + 300;
    inCase.samples.length = 0;
    collectCase().forEach(u => { if (u.el.getBoundingClientRect().top < vh * ARM) arm(u, state(u.id, true), now); });
    if (started) soon(320);
  }
  // Кейс закрыт: его сцены снимаются, блоки забываются
  function caseClose() {
    if (!caseOn) return;
    const pre = 'case' + caseOn + ':';
    caseOn = 0;
    units.forEach((st, id) => {
      if (!id.startsWith(pre)) return;
      if (st.s === 'running') finish(st);
      else if (st.s === 'queued') { unqueue(st); disarm(st); }
      else if (st.s === 'armed') disarm(st);
      units.delete(id);
    });
  }
  Scenes.caseOpen = caseOpen;
  Scenes.caseClose = caseClose;

  /* ---------- Старт ---------- */

  function start() {
    started = true;
    if (test) { runTest(); return; }
    // Кейс открыт по ссылке ещё до старта сцен
    if (!caseOn && caseEl && !caseEl.hidden && caseBody && caseBody.firstElementChild) caseOpen();
    // Блоки, которые к старту уже в окне или выше (страница открыта посередине), показываются как есть
    const vh = innerHeight;
    collect().forEach(u => {
      const st = state(u.id);
      if (st.s !== 'done' && u.el.getBoundingClientRect().top < vh) markDone(st);
    });
    check();
    setInterval(() => { if (!document.hidden) check(); }, 1500);
  }

  // ?scenetest=id: остальные блоки показаны (без записи), страница встаёт на блок, сцена идёт или замирает
  function runTest() {
    const list = collect(), u = list.find(x => x.id === test[1]);
    if (!u) { console.warn('scenetest: нет блока', test[1], list.map(x => x.id)); return; }
    list.forEach(x => { if (x !== u) units.set(x.id, { id: x.id, s: 'done', hides: [] }); });
    const st = { id: u.id, s: 'idle', hides: [] };
    units.set(u.id, st);
    const r = u.el.getBoundingClientRect();
    scrollTo({ top: r.top + scrollY - innerHeight * .14, behavior: 'instant' });
    arm(u, st, performance.now());
    queue(u, st, 0, Math.min(u.want, budget()), false);
    clearTimeout(st.timer);
    begin(u, st, false);
  }

  // Ждём шрифты (от них зависят размеры), но не дольше 600 мс
  const fonts = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
  Promise.race([fonts, new Promise(r => setTimeout(r, 600))]).then(() => { try { start(); } catch (e) { if (Kit.dev) console.warn('scenes', e); } });
})();
