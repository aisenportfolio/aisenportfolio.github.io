/* Логика портфолио: карточки работ и кейс из data.js, свет от курсора,
   появление блоков при прокрутке. Анимируются только transform и opacity. */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const CASES = Array.isArray(window.CASES) ? window.CASES : [];
  const TG = 'https://t.me/meph1st6';
  const I18N = window.I18N;
  const T = (key, ...a) => I18N ? I18N.t(key, ...a) : key;

  /* Кейс на текущем языке: английские поля из CASES_EN поверх русских. Картинки, ссылки и цифры общие */
  function loc(c) {
    const en = I18N && I18N.lang === 'en' && window.CASES_EN && window.CASES_EN[c.slug];
    if (!en) return c;
    const out = { ...c, ...en };
    if (c.cover && en.cover) out.cover = { desktop: c.cover.desktop && { ...c.cover.desktop, ...en.cover.desktop }, mobile: c.cover.mobile && { ...c.cover.mobile, ...en.cover.mobile } };
    if (c.shots && en.shots) out.shots = c.shots.map((s, i) => ({ ...s, ...(en.shots[i] || {}) }));
    if (c.before && en.before) out.before = c.before.map((b, i) => ({ ...b, ...(en.before[i] || {}) }));
    if (c.numbers && en.numbers) out.numbers = c.numbers.map((n, i) => ({ ...n, ...(en.numbers[i] || {}) }));
    if (c.facts && en.facts) out.facts = c.facts.map((x, i) => ({ ...x, ...(en.facts[i] || {}) }));
    if (c.after && en.after) out.after = { ...c.after, ...en.after };
    return out;
  }

  /* Плавное следование за точкой: элемент двигается через transform */
  function follower(el, k) {
    let x = 0, y = 0, tx = 0, ty = 0, raf = 0, placed = false;
    const draw = () => { el.style.transform = `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0)`; };
    const step = () => {
      x += (tx - x) * k; y += (ty - y) * k; draw();
      raf = Math.abs(tx - x) + Math.abs(ty - y) > .3 ? requestAnimationFrame(step) : 0;
    };
    return {
      to(nx, ny, jump) {
        tx = nx; ty = ny;
        if (jump || !placed) { x = nx; y = ny; placed = true; draw(); }
        else if (!raf) raf = requestAnimationFrame(step);
      }
    };
  }

  /* Картинка из data.js: { src, w: [ширины], ratio, alt } */
  function img(i, sizes, lazy = true) {
    const set = i.w.map(w => `${i.src}-${w}.webp ${w}w`).join(', ');
    return `<img src="${i.src}-${i.w[0]}.webp" srcset="${set}" sizes="${sizes}" alt="${esc(i.alt || '')}" style="aspect-ratio:${i.ratio}"${lazy ? ' loading="lazy"' : ''} decoding="async">`;
  }

  /* ---------- Работы ---------- */

  const grid = $('#works-grid');
  function renderCards() {
    if (!grid) return;
    const cards = CASES.map(loc).map(c => `
      <a class="card rv" href="#work/${esc(c.slug)}" data-slug="${esc(c.slug)}">
        <span class="card__glow" aria-hidden="true"></span>
        <div class="card__in">
          ${c.cover ? `<div class="card__shots" aria-hidden="true">
            ${c.cover.desktop ? `<span class="shot shot--desk">${img({ ...c.cover.desktop, alt: '' }, '(max-width: 639px) 100vw, (max-width: 1099px) 50vw, 440px')}</span>` : ''}
            ${c.cover.mobile ? `<span class="shot shot--phone">${img({ ...c.cover.mobile, alt: '' }, '(max-width: 639px) 26vw, 120px')}</span>` : ''}
          </div>` : ''}
          <div class="card__copy">
            <p class="card__client"><span>${esc(c.client)}${c.city ? ', ' + esc(c.city) : ''}</span>${c.year ? `<span>${esc(c.year)}</span>` : ''}</p>
            <h3 class="card__title">${esc(c.title)}</h3>
            ${c.summary ? `<p class="card__text">${esc(c.summary)}</p>` : ''}
            <span class="card__more">${esc(T('card.more'))}</span>
          </div>
        </div>
      </a>`);
    // Последняя плитка — приглашение написать. Она занимает свободные колонки последнего ряда,
    // чтобы ряд не обрывался пустым местом: при трёх колонках и при двух
    const n = CASES.length, s3 = 3 - n % 3, s2 = 2 - n % 2;
    cards.push(`
      <a class="card card--cta${s3 === 3 ? ' card--wide' : ''} rv" href="${TG}" target="_blank" rel="noopener" style="--span3:${s3};--span2:${s2}">
        <span class="card__glow" aria-hidden="true"></span>
        <div class="card__in">
          <p class="card__client">${esc(T('card.next'))}</p>
          <h3 class="card__title">${esc(T('card.ask'))}</h3>
          <span class="card__more">${esc(T('hero.tg'))}</span>
        </div>
      </a>`);
    grid.innerHTML = cards.join('');
  }

  /* ---------- Кейс ---------- */

  const arrow = '<svg viewBox="0 0 120 24" aria-hidden="true"><path d="M0 12h116M106 3l10 9-10 9" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>';
  const list = (title, items, cls = '') => items && items.length
    ? `<div class="rv${cls ? ' ' + cls : ''}"><h3>${title}</h3><ul>${items.map(i => `<li>${esc(i)}</li>`).join('')}</ul></div>` : '';

  function renderCase(c) {
    c = loc(c);
    const host = c.url ? new URL(c.url).host : '';
    const parts = [];

    parts.push(`
      <header class="case__head">
        <p class="case__client rv">${esc(c.client)}${c.city ? ', ' + esc(c.city) : ''}</p>
        <h2 class="case__title" id="case-title"><span class="ln rv-line"><span>${esc(c.title)}</span></span></h2>
        <div class="grid12">
          ${c.summary ? `<p class="case__lead rv">${esc(c.summary)}</p>` : ''}
          <dl class="case__meta rv">
            ${c.role ? `<div><dt>${esc(T('case.role'))}</dt><dd>${esc(c.role.join(', '))}</dd></div>` : ''}
            ${c.year ? `<div><dt>${esc(T('case.year'))}</dt><dd>${esc(c.year)}</dd></div>` : ''}
            ${host ? `<div><dt>${esc(T('case.site'))}</dt><dd><a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(host)}</a></dd></div>` : ''}
          </dl>
        </div>
        ${c.url ? `<a class="btn case__link rv" href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.urlLabel || T('case.open'))}</a>` : ''}
      </header>`);

    if (c.cover && c.cover.desktop) {
      parts.push(`<figure class="case__cover rv">${img(c.cover.desktop, '(max-width: 1400px) 92vw, 1320px', false)}</figure>`);
    }

    if ((c.numbers && c.numbers.length) || (c.facts && c.facts.length)) {
      parts.push(`<section class="nums" aria-label="${esc(T('case.numbers'))}">
        ${(c.numbers || []).map(n => `
          <div class="nums__pair rv">
            <p class="nums__side"><span class="nums__n">${esc(n.from)}</span><span class="nums__l">${esc(n.fromLabel)}</span></p>
            <span class="nums__arrow">${arrow}</span>
            <p class="nums__side nums__side--to"><span class="nums__n">${esc(n.to)}</span><span class="nums__l">${esc(n.toLabel)}</span></p>
          </div>`).join('')}
        ${(c.facts || []).map(f => `<p class="fact rv"><b>${esc(f.value)}</b><span>${esc(f.label)}</span></p>`).join('')}
      </section>`);
    }

    if (c.problem || c.solution) {
      parts.push(`<section class="grid12 duo">
        ${c.problem ? `<div class="rv"><p class="label">${esc(T('case.problem'))}</p><p>${esc(c.problem)}</p></div>` : ''}
        ${c.solution ? `<div class="rv"><p class="label">${esc(T('case.solution'))}</p><p>${esc(c.solution)}</p></div>` : ''}
      </section>`);
    }

    if (c.before && c.before.length && c.after) {
      parts.push(`<section class="merge" aria-label="${esc(T('case.merge'))}">
        <div class="merge__col rv">
          <p class="label">${esc(T('case.before', c.before.length))}</p>
          <ul class="merge__from">${c.before.map(b => `<li class="tile"><b>${esc(b.name)}</b>${b.url ? `<span>${esc(b.url)}</span>` : ''}</li>`).join('')}</ul>
        </div>
        <div class="merge__mid rv">${arrow}</div>
        <div class="merge__col rv">
          <p class="label">${esc(T('case.after'))}</p>
          <div class="tile tile--to"><b>${esc(c.after.name)}</b>${c.after.note ? `<span>${esc(c.after.note)}</span>` : ''}</div>
        </div>
      </section>`);
    }

    const lists = list(T('case.removed'), c.removed, 'is-removed') + list(T('case.added'), c.added) + list(T('case.easier'), c.easier);
    if (lists) parts.push(`<section class="grid12 lists">${lists}</section>`);

    if (c.shots && c.shots.length) {
      // Ряды: широкий экран начинает ряд и берёт к себе один телефонный; телефонные без пары идут по три
      const rows = [];
      c.shots.forEach(s => {
        const row = rows[rows.length - 1];
        const phones = row ? row.filter(x => x.phone).length : 0;
        if (s.phone && row && (row[0].phone ? row.length < 3 : phones < 1)) row.push(s);
        else rows.push([s]);
      });
      const figure = s => {
        const [w, h] = s.ratio.split('/').map(Number);
        return `<figure class="rv${s.phone ? ' is-phone' : ''}" style="flex:${(w / h).toFixed(3)} 1 0">${img(s, s.phone ? '(max-width: 899px) 72vw, 24vw' : '(max-width: 899px) 92vw, 70vw')}${s.caption ? `<figcaption>${esc(s.caption)}</figcaption>` : ''}</figure>`;
      };
      parts.push(`<section class="shots" aria-labelledby="shots-title">
        <h3 class="case__sub rv" id="shots-title">${esc(T('case.shots'))}</h3>
        ${rows.map(r => `<div class="gallery">${r.map(figure).join('')}</div>`).join('')}
      </section>`);
    }

    const tail = list(T('case.myRole'), c.role) + list(T('case.stack'), c.stack) + list(T('case.tools'), c.tools);
    if (tail) parts.push(`<section class="grid12 lists">${tail}</section>`);

    parts.push(`<footer class="case__end rv">
      <h3>${esc(T('case.end'))}</h3>
      <div>
        <a class="btn" href="${TG}" target="_blank" rel="noopener">${esc(T('hero.tg'))}</a>
        ${c.url ? `<a class="btn btn--ghost" href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.urlLabel || T('case.open'))}</a>` : ''}
      </div>
    </footer>`);

    return parts.join('');
  }

  function plural(n, one, few, many) {
    const a = n % 10, b = n % 100;
    return a === 1 && b !== 11 ? one : a >= 2 && a <= 4 && (b < 12 || b > 14) ? few : many;
  }

  const caseEl = $('#case'), caseBg = $('#case-bg'), caseScroll = $('#case-scroll'), caseBody = $('#case-body');
  const outside = [$('#theme'), $('#header'), $('#main'), $('#footer')];
  let opened = null, originCard = null, viaClick = false, closeTimer = 0, lockTimer = 0;

  /* Фон кейса вырастает из карточки и сворачивается обратно в неё */
  function growFrom(card, reverse) {
    if (calm || !caseBg.animate) return;
    const r = card && card.getBoundingClientRect();
    const visible = r && r.bottom > 0 && r.top < innerHeight;
    const from = visible
      ? { transform: `translate3d(${r.left}px,${r.top}px,0) scale(${r.width / innerWidth},${r.height / innerHeight})`, opacity: .6 }
      : { transform: 'none', opacity: 0 };
    const to = { transform: 'none', opacity: 1 };
    caseBg.animate(reverse ? [to, from] : [from, to], { duration: reverse ? 480 : 720, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'both' });
  }

  function openCase(c) {
    clearTimeout(closeTimer);
    opened = c.slug;
    originCard = originCard || $(`.card[data-slug="${c.slug}"]`);
    caseBody.innerHTML = renderCase(c);
    caseEl.hidden = false;
    caseScroll.scrollTop = 0;
    // Страницу под кейсом фиксируем после анимации, иначе она дёрнется на ширину полосы прокрутки
    lockTimer = setTimeout(() => document.documentElement.classList.add('is-locked'), calm ? 0 : 740);
    outside.forEach(el => el && (el.inert = true));
    document.title = T('case.docTitle', loc(c).title);
    growFrom(originCard, false);
    requestAnimationFrame(() => requestAnimationFrame(() => caseEl.classList.add('is-open')));
    watch(caseBody);
    if (window.Scenes) Scenes.caseOpen();           // сборка кейса курсорами (js/scenes.js)
    $('#case-close').focus({ preventScroll: true });
  }

  function closeCase() {
    if (!opened) return;
    opened = null;
    if (window.Scenes) Scenes.caseClose();
    caseEl.classList.remove('is-open');
    growFrom(originCard, true);
    outside.forEach(el => el && (el.inert = false));
    clearTimeout(lockTimer);
    document.documentElement.classList.remove('is-locked');
    document.title = T('meta.title');
    const back = originCard;
    closeTimer = setTimeout(() => { caseEl.hidden = true; caseBody.innerHTML = ''; }, calm ? 0 : 500);
    if (back) back.focus({ preventScroll: true });
    originCard = null; viaClick = false;
  }

  /* Адрес кейса: #work/<slug>. Кнопка «назад» в браузере закрывает кейс */
  function route() {
    const m = location.hash.match(/^#work\/([\w-]+)$/);
    const c = m && CASES.find(x => x.slug === m[1]);
    if (c) { if (opened !== c.slug) openCase(c); }
    else closeCase();
  }
  function requestClose() {
    if (viaClick) history.back();
    else { history.replaceState(null, '', location.pathname + location.search + '#works'); closeCase(); $('#works').scrollIntoView(); }
  }

  /* ---------- Появление при прокрутке ---------- */

  const io = 'IntersectionObserver' in window && !calm
    ? new IntersectionObserver(entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); }
      }), { threshold: .12, rootMargin: '0px 0px -6% 0px' })
    : null;

  function watch(root) {
    const items = $$('.rv, .rv-line', root);
    const seen = new Map();
    items.forEach(el => {
      const n = seen.get(el.parentNode) || 0;
      seen.set(el.parentNode, n + 1);
      el.style.setProperty('--i', Math.min(n, 6));
      if (io) io.observe(el); else el.classList.add('is-in');
    });
  }

  /* ---------- Прокрутка: портрет, текст «Обо мне», линия шагов ---------- */

  const hero = $('#top'), portrait = $('#portrait'), heroCopy = $('#hero-copy');
  const lead = $('#about-lead'), steps = $('#steps'), stepsBar = $('#steps-bar');
  let words = [], lit = [];

  /* Абзац «Обо мне» на текущем языке; при прокрутке его слова проявляются по очереди */
  function splitLead() {
    if (!lead) return;
    const text = T('about.lead');
    if (calm) { lead.textContent = text; words = []; return; }
    lead.innerHTML = text.split(/\s+/).map(w => `<span class="w">${esc(w)}</span>`).join(' ');
    words = $$('.w', lead);
    lit = words.map(() => -1);
  }
  splitLead();

  function onScroll() {
    const vh = innerHeight, y = scrollY;

    if (hero && y < hero.offsetHeight * 1.1) {
      const p = clamp(y / (hero.offsetHeight * .9));
      portrait.style.opacity = (1 - p * .9).toFixed(3);
      portrait.style.transform = `translate3d(0,${(p * 70).toFixed(1)}px,0) scale(${(1 + p * .05).toFixed(4)})`;
      heroCopy.style.transform = `translate3d(0,${(-p * 46).toFixed(1)}px,0)`;
    }

    if (words.length) {
      const r = lead.getBoundingClientRect();
      if (r.top < vh && r.bottom > -vh * .2) {
        const t = clamp((vh * .86 - r.top) / (r.height + vh * .34));
        const head = t * (words.length + 8);
        words.forEach((w, i) => {
          const o = Math.round((.2 + .8 * clamp((head - i) / 8)) * 100) / 100;
          if (o !== lit[i]) { lit[i] = o; w.style.opacity = o; }
        });
      }
    }

    if (steps) {
      const r = steps.getBoundingClientRect();
      if (r.top < vh && r.bottom > 0) {
        stepsBar.style.transform = `scaleX(${clamp((vh * .82 - r.top) / (vh * .5)).toFixed(4)})`;
        const list = $$('.step', steps), wide = innerWidth > 899;
        const t = clamp((vh * .82 - r.top) / (vh * .5));
        list.forEach((s, i) => s.classList.toggle('is-on', wide ? t >= (i + .35) / list.length : s.getBoundingClientRect().top < vh * .8));
      }
    }
  }

  let ticking = false;
  const queue = () => { if (!ticking) { ticking = true; requestAnimationFrame(() => { ticking = false; onScroll(); }); } };

  /* ---------- Свет ---------- */

  function initLight() {
    const light = $('#light'), photo = $('#photo'), glow = $('#glow');
    const spot = follower(light, .085);
    const rest = () => { const r = portrait.getBoundingClientRect(); spot.to(r.width * .5, r.height * .34, true); };
    rest();
    addEventListener('resize', rest);
    if (!fine || calm) return;

    const page = follower(glow, .1), drift = follower(photo, .06);
    addEventListener('pointermove', e => {
      page.to(e.clientX, e.clientY);
      glow.classList.add('is-on');
      if (scrollY < innerHeight) {
        const r = portrait.getBoundingClientRect();
        spot.to(clamp(e.clientX - r.left, -r.width * .2, r.width * 1.2), clamp(e.clientY - r.top, 0, r.height));
        drift.to((e.clientX / innerWidth - .5) * -16, (e.clientY / innerHeight - .5) * -10);
      }
    }, { passive: true });
    document.documentElement.addEventListener('pointerleave', () => { glow.classList.remove('is-on'); rest(); });

    bindCards();

    /* Крупные ссылки контактов */
    $$('.biglink').forEach(a => {
      const s = document.createElement('span');
      s.className = 'biglink__lit'; s.setAttribute('aria-hidden', 'true');
      a.prepend(s);
      const f = follower(s, .16);
      a.addEventListener('pointermove', e => { const r = a.getBoundingClientRect(); f.to(e.clientX - r.left, e.clientY - r.top); });
    });
  }

  /* Карточки работ: свет по кромке, лёгкий наклон, сдвиг скриншотов. Вызывается и после перерисовки карточек */
  function bindCards() {
    if (!fine || calm) return;
    $$('.card').forEach(card => {
      const g = follower($('.card__glow', card), .18);
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect();
        g.to(e.clientX - r.left, e.clientY - r.top);
        card.style.setProperty('--tx', ((e.clientX - r.left) / r.width - .5).toFixed(3));
        card.style.setProperty('--ty', ((e.clientY - r.top) / r.height - .5).toFixed(3));
      });
      card.addEventListener('pointerleave', () => { card.style.setProperty('--tx', 0); card.style.setProperty('--ty', 0); });
    });
  }

  /* ---------- Портрет рассыпается в пыль ---------- */

  /* Пасхалка: клик по портрету. Снимок переносится на canvas и распадается по клеткам,
     от места клика наружу: клетка отрывается, крошится в пылинку, ветер уносит её вправо.
     Когда портрет почти исчез, текст первого экрана плавно встаёт по центру.
     Срабатывает один раз, после перезагрузки страницы портрет возвращается.
     Тот же распад убирает портрет при первом включении светлой темы (themeHero) */

  const DUST = {
    spread: 1,           // с, за сколько фронт распада проходит весь снимок
    life: [.5, .9],      // с, сколько живёт одна частица
    shiftAt: .7,         // доля spread, после которой текст начинает переезжать
    shift: 1150,         // мс, сколько длится переезд текста
    stagger: 110,        // мс, на сколько каждая следующая строка трогается позже предыдущей
    ease: 'cubic-bezier(.62, .02, .2, 1)'
  };

  /* Включает раскладку без портрета. Экран при этом не должен стать ниже,
     иначе разделы под ним подпрыгнут; высоту отпускаем при повороте экрана */
  function solo() {
    const tall = hero.offsetHeight, wide = innerWidth;
    hero.classList.add('is-solo');
    if (hero.offsetHeight >= tall) return;
    hero.style.minHeight = tall + 'px';
    addEventListener('resize', function free() {
      if (innerWidth === wide) return;
      hero.style.minHeight = ''; removeEventListener('resize', free);
    });
  }

  /* Текст первого экрана переезжает в центр (on) или обратно влево. Раскладка меняется сразу,
     а каждый кусок текста удерживается на старом месте через transform и через delay мс
     плавно едет на новое (FLIP). Сдвига вёрстки на глазах у посетителя нет. Если прошлый переезд
     ещё идёт, новый стартует с того места, где текст виден сейчас */
  function settle(delay, on = true) {
    // Слова описания двигаются по отдельности: при выравнивании по центру строки сдвигаются по-разному.
    // Слово с дефисом режем после дефиса, чтобы строки переносились там же, где и раньше
    const lead = $('.hero__lead', heroCopy);
    if (!$('.hw', lead)) {
      lead.innerHTML = lead.textContent.trim().split(/\s+/)
        .map(w => w.split('-').map((part, i, all) => `<span class="hw">${esc(part)}${i < all.length - 1 ? '-' : ''}</span>`).join(''))
        .join(' ');
    }
    const items = [$('.hero__who', heroCopy), ...$$('.hero__title .ln', heroCopy), ...$$('.hw', lead), ...$('.hero__row', heroCopy).children];
    // Строка заголовка — блок во всю ширину заголовка, а короткая строка при центровке смещается внутри
    // своего блока. Поэтому для строк меряем сам текст, иначе «Собираю» и «сложное» перескакивают в момент клика
    const box = el => {
      const text = el.classList.contains('ln') && el.firstElementChild;
      if (!text) return el.getBoundingClientRect();
      const range = document.createRange();
      range.selectNodeContents(text);
      return range.getBoundingClientRect();
    };
    const from = items.map(box);
    items.forEach(el => el.getAnimations().forEach(a => { if (a.id === 'settle') a.cancel(); }));
    // Строки трогаются по очереди сверху вниз, как волна. Всё, что стоит на одной строке
    // (слова описания, две кнопки), едет вместе
    const line = new Array(items.length);
    let n = -1, top = -Infinity;
    from.map((r, i) => i).sort((a, b) => from[a].top - from[b].top).forEach(i => {
      if (from[i].top - top > 6) { n++; top = from[i].top; }
      line[i] = n;
    });
    if (on) solo(); else hero.classList.remove('is-solo');
    const to = items.map(box);
    // Волна идёт по ходу движения: если текст едет вниз, первой трогается нижняя строка, иначе строки наезжают друг на друга
    const down = to.reduce((sum, r, i) => sum + r.top - from[i].top, 0) > 0;
    items.forEach((el, i) => {
      const dx = from[i].left - to[i].left, dy = from[i].top - to[i].top;
      if (Math.abs(dx) + Math.abs(dy) < .5) return;
      el.animate([{ transform: `translate3d(${dx.toFixed(2)}px,${dy.toFixed(2)}px,0)` }, { transform: 'none' }],
        { id: 'settle', duration: DUST.shift, delay: delay + (down ? n - line[i] : line[i]) * DUST.stagger, easing: DUST.ease, fill: 'backwards' });
    });
  }

  /* Готовит снимок к распаду: рисует его на canvas в том же виде, что на странице, и снимает
     цвет каждой клетки. Делается заранее, как только курсор или палец оказался на портрете,
     чтобы сам клик не подтормаживал. Готовый снимок не меняется: каждая сцена распада работает
     со своей копией. Возвращает null, если пиксели снимка недоступны */
  let baked = null;
  function bake() {
    const img = $('#photo img'), W = portrait.offsetWidth, H = portrait.offsetHeight;
    if (baked && baked.W === W && baked.H === H) return baked;
    baked = null;
    if (!W || !H || !img.complete || !img.naturalWidth) return null;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    const S = Math.min(dpr, Math.sqrt(2.2e6 / (W * H)));           // масштаб слоя со снимком
    const BW = Math.round(W * S), BH = Math.round(H * S);
    // Сетка клеток. Размер клетки целый в пикселях canvas, иначе между клетками остаются швы
    const cb = Math.max(2, Math.round((W * H > 5e5 ? 3 : 2) * S)), cols = Math.ceil(BW / cb), rows = Math.ceil(BH / cb);
    const src = document.createElement('canvas'), tiny = document.createElement('canvas');
    src.width = BW; src.height = BH; tiny.width = cols; tiny.height = rows;
    const sctx = src.getContext('2d'), tctx = tiny.getContext('2d', { willReadFrequently: true });
    if (!sctx || !tctx) return null;

    // Яркость и контраст берём из CSS-фильтра снимка
    const css = getComputedStyle(img).filter;
    const num = name => { const m = new RegExp(name + '\\(([\\d.]+)\\)').exec(css); return m ? +m[1] : 1; };
    const bright = num('brightness'), contrast = num('contrast');
    const lut = new Uint8ClampedArray(256);
    for (let i = 0; i < 256; i++) lut[i] = ((i / 255 * bright - .5) * contrast + .5) * 255;
    const recolor = d => { for (let i = 0; i < d.length; i += 4) { d[i] = lut[d[i]]; d[i + 1] = lut[d[i + 1]]; d[i + 2] = lut[d[i + 2]]; } };
    let colors;
    try {
      sctx.imageSmoothingQuality = tctx.imageSmoothingQuality = 'high';
      if ('filter' in sctx) {
        sctx.filter = `brightness(${bright}) contrast(${contrast})`;
        sctx.drawImage(img, 0, 0, BW, BH);
        sctx.filter = 'none';
      } else {                                                      // у canvas нет фильтров: перекрашиваем пиксели сами
        sctx.drawImage(img, 0, 0, BW, BH);
        const full = sctx.getImageData(0, 0, BW, BH);
        recolor(full.data); sctx.putImageData(full, 0, 0);
      }
      // Цвета клеток: тот же снимок, уменьшенный до одной точки на клетку
      tctx.drawImage(img, 0, 0, BW / cb, BH / cb);
      colors = tctx.getImageData(0, 0, cols, rows).data;
    } catch (e) { return null; }                                    // страница открыта как файл: пиксели недоступны
    recolor(colors);
    return baked = { W, H, S, dpr, cb, cols, rows, src, colors };
  }

  /* План распада от точки клика: когда гаснет каждая клетка, куда летит её пыль, где фон снимка.
     От темы не зависит, поэтому для тумблера темы (точка всегда одна) считается один раз и заранее */
  let planned = null;
  function plan(shot, clickX, clickY) {
    if (planned && planned.shot === shot && planned.x === clickX && planned.y === clickY) return planned;
    const { W, H, S, dpr, cb, cols, rows, colors } = shot;
    const total = cols * rows, cell = cb / S;
    // Слой с пылью: клетка и на нём занимает целое число пикселей. На плотном экране с мышью пыль мельче,
    // на телефоне слой остаётся в размер страницы: так он вдвое легче для процессора
    const bp = Math.max(2, Math.round(cell * Math.min(fine && dpr > 1 ? 1.5 : 1, Math.sqrt(1.2e6 / (W * H))))), D = bp / cell;

    // Плавный шум, чтобы край распада был рваным, а пыль летела прядями
    const NS = 24, grid = Float32Array.from({ length: (NS + 1) * (NS + 1) }, Math.random);
    const noise = (x, y) => {
      const xi = x | 0, yi = y | 0, fx = x - xi, fy = y - yi, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy), o = yi * (NS + 1) + xi;
      const a = grid[o], b = grid[o + 1], c = grid[o + NS + 1], d = grid[o + NS + 2];
      return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
    };

    // Края портрета растворяет маска из CSS (два градиента: сверху вниз и слева направо).
    // Читаем её, чтобы знать, какие клетки видны на экране: темп распада задают только они
    const shade = getComputedStyle(portrait);
    const stops = ((shade.maskImage || shade.webkitMaskImage || '').match(/[\d.]+(?=%)/g) || []).map(s => s / 100);
    const m = stops.length === 8 ? stops : [0, .2, .6, 1, 0, .3, .7, 1];
    const edge = (t, a, b, c, d) => clamp((t - a) / (b - a)) * clamp((d - t) / (d - c));

    // Когда распадается каждая клетка: чем дальше от клика, тем позже. По ветру фронт идёт быстрее
    const ox = clickX / W, oy = clickY / H, ratio = H / W;
    const when = new Float32Array(total), seen = new Uint8Array(total);
    let lo = Infinity, hi = -Infinity;
    for (let cy = 0, c = 0; cy < rows; cy++) for (let cx = 0; cx < cols; cx++, c++) {
      const u = (cx + .5) / cols, v = (cy + .5) / rows, dx = u - ox, dy = (v - oy) * ratio, o = c * 4;
      const key = Math.hypot(dx * (dx > 0 ? .4 : 1.25), dy) + (noise(u * 7, v * 7 * ratio) - .5) * .2 + Math.random() * .04;
      const vis = seen[c] = Math.max(colors[o], colors[o + 1], colors[o + 2]) * edge(v, m[0], m[1], m[2], m[3]) * edge(u, m[4], m[5], m[6], m[7]);
      when[c] = key;
      if (vis >= 14) { if (key < lo) lo = key; if (key > hi) hi = key; }
    }
    if (!(hi > lo)) { lo = 0; hi = 1; }
    // Клетки по порядку распада: сортировка подсчётом по 240 отрезкам времени
    const NB = 240, starts = new Uint32Array(NB + 2), order = new Uint32Array(total);
    for (let c = 0; c < total; c++) { when[c] = clamp((when[c] - lo) / (hi - lo)) * DUST.spread; starts[Math.min(NB - 1, when[c] / DUST.spread * NB | 0) + 2]++; }
    for (let b = 2; b < NB + 2; b++) starts[b] += starts[b - 1];
    for (let c = 0; c < total; c++) order[starts[Math.min(NB - 1, when[c] / DUST.spread * NB | 0) + 1]++] = c;

    // Частицы: по одной на клетку, где на снимке что-то видно. Тёмный фон пыли не даёт
    const k = W / 720 * D;
    const x0 = new Uint16Array(total), y0 = new Uint16Array(total), born = new Float32Array(total), life = new Float32Array(total);
    const push = new Float32Array(total), rise = new Float32Array(total), sway = new Float32Array(total), phase = new Float32Array(total);
    const own = new Uint32Array(total), warm = new Float32Array(total);
    let n = 0;
    for (let cy = 0, c = 0; cy < rows; cy++) for (let cx = 0; cx < cols; cx++, c++) {
      if (seen[c] < 14) continue;
      own[n] = (colors[c * 4 + 2] << 16) | (colors[c * 4 + 1] << 8) | colors[c * 4];   // цвет снимка: с ним клетка отрывается
      warm[n] = .2 + Math.random() * .22;
      x0[n] = cx * bp; y0[n] = cy * bp;
      born[n] = when[c];
      life[n] = DUST.life[0] + Math.random() * (DUST.life[1] - DUST.life[0]);
      // Соседние частицы летят похоже (общий шум), поэтому пыль идёт прядями, а не ровным облаком
      const u = cx / cols, v = cy / rows, gust = noise(u * 4 + 9, v * 4 * ratio), drift = noise(u * 3, v * 3 * ratio + 11);
      push[n] = (430 + gust * 380 + Math.random() * 330) * k;       // сила ветра
      rise[n] = ((drift - .62) * 150 + (Math.random() - .5) * 50) * k;   // чуть вверх или вниз
      sway[n] = (8 + Math.random() * 20) * k; phase[n] = drift * 9 + Math.random() * .8;
      n++;
    }

    // Маска фона снимка (клетки без частиц): одна точка на клетку
    const mask = document.createElement('canvas'), mctx = mask.getContext('2d');
    if (!mctx) return null;
    mask.width = cols; mask.height = rows;
    const md = mctx.createImageData(cols, rows);
    for (let c = 0; c < total; c++) if (seen[c] < 14) md.data[c * 4 + 3] = 255;
    mctx.putImageData(md, 0, 0);

    return planned = { shot, x: clickX, y: clickY, bp, D, NB, starts, order, seen, n, x0, y0, born, life, push, rise, sway, phase, own, warm, mask };
  }

  /* Распад на частицы. Время сцены v идёт от 0 (снимок цел) до end (пыль унесена ветром), и кадр зависит
     только от v. Поэтому сцену можно пустить назад и развернуть на ходу: run(1) — распад, run(-1) — пыль
     слетается обратно и собирает снимок. from: 'shown' — сцена начинается с целого снимка, 'hidden' — с пустого
     места. Возвращает null, если canvas недоступен: тогда снимок просто гаснет */
  function makeDust(clickX, clickY, from) {
    const shot = bake();
    const P = shot && plan(shot, clickX, clickY);
    if (!P) return null;
    const { W, H, cb, cols, rows, src } = shot;
    const { bp, D, NB, starts, order, seen, n, x0, y0, born, life, push, rise, sway, phase, own, warm, mask } = P;
    const photo = $('#photo'), light = $('#light');
    const DW = Math.round(W * D), DH = Math.round(H * D);
    const dust = document.createElement('canvas'), live = document.createElement('canvas'), back = document.createElement('canvas');
    dust.width = DW; dust.height = DH; live.width = back.width = src.width; live.height = back.height = src.height;
    const dctx = dust.getContext('2d'), lctx = live.getContext('2d'), bctx = back.getContext('2d');
    if (!dctx || !lctx || !bctx) return null;

    // В полёте крошка становится пеплом, заметным на фоне страницы: на тёмном — светлым и тёплым,
    // на светлом (тема переключена) — тёплым серым
    const pale = document.documentElement.dataset.theme === 'light';
    const ash = new Uint32Array(n);
    for (let i = 0; i < n; i++) {
      let r = own[i] & 255, g = own[i] >> 8 & 255, b = own[i] >> 16;
      const w = warm[i];
      if (pale) {
        r += (118 - r) * (w + .3); g += (98 - g) * (w + .3); b += (84 - b) * (w + .3);
      } else {
        const lum = Math.max(r, g, b, 1), lift = lum < 104 ? 104 / lum : 1;
        r = Math.min(255, r * lift); g = Math.min(255, g * lift); b = Math.min(255, b * lift);
        r += (236 - r) * w; g += (208 - g) * w; b += (182 - b) * w;
      }
      ash[i] = (b << 16) | (g << 8) | (r | 0);
    }

    // Снимок делится на два слоя. Фигура (клетки, где что-то видно) рассыпается пылью, тёмный фон снимка
    // (клетки без частиц) плавно гаснет вместе со сменой темы: на тёмной странице его и так не видно,
    // а на светлой он висел бы серым пятном. Маска фона растягивается без сглаживания
    const cut = (ctx, op) => {
      ctx.drawImage(src, 0, 0);
      ctx.globalCompositeOperation = op; ctx.imageSmoothingEnabled = false;
      ctx.drawImage(mask, 0, 0, cols * cb, rows * cb);
      ctx.globalCompositeOperation = 'source-over';
    };
    cut(bctx, 'destination-in');
    back.style.opacity = from === 'hidden' ? 0 : 1;

    // Подменяем снимок слоем: с этого кадра портрет рисует canvas. Свет остаётся поверх и гаснет сам
    const layer = document.createElement('div');
    layer.className = 'hero__dust';
    layer.style.transform = photo.style.transform;
    const zoom = getComputedStyle($('img', photo)).transform;
    back.style.transform = live.style.transform = dust.style.transform = zoom === 'none' ? '' : zoom;
    layer.append(back, live, dust);
    portrait.insertBefore(layer, light);
    photo.style.visibility = 'hidden';
    photo.style.opacity = '';
    if (light) { light.style.transition = 'opacity .7s'; light.style.opacity = 0; }

    const image = dctx.createImageData(DW, DH), buf = new Uint32Array(image.data.buffer);
    const end = DUST.spread + DUST.life[1] + .05, BW = src.width, BH = src.height;
    let t = from === 'hidden' ? end : 0, front = from === 'hidden' ? NB : 0, dir = 0, raf = 0, last = 0, onEnd = null;
    if (!front) cut(lctx, 'destination-out');

    // Клетки между двумя положениями фронта: при распаде стираются со снимка, при сборке рисуются заново
    const cells = (a, b, redraw) => {
      for (let q = a; q < b; q++) for (let j = starts[q]; j < starts[q + 1]; j++) {
        const c = order[j], x = (c % cols) * cb, y = (c / cols | 0) * cb;
        if (seen[c] < 14) continue;                                 // клетка фона: она на своём слое
        if (redraw) lctx.drawImage(src, x, y, Math.min(cb, BW - x), Math.min(cb, BH - y), x, y, Math.min(cb, BW - x), Math.min(cb, BH - y));
        else lctx.clearRect(x, y, cb, cb);
      }
    };
    const paint = () => {
      const upto = Math.min(NB, Math.ceil(t / DUST.spread * NB));
      if (upto > front) cells(front, upto, false); else if (upto < front) cells(upto, front, true);
      front = upto;
      // Рисуем живые частицы прямо в пиксели: место частицы считается от её возраста, без накопления шагов
      buf.fill(0);
      for (let i = 0; i < n; i++) {
        const age = t - born[i];
        if (age < 0) continue;
        const f = age / life[i];
        if (f >= 1) continue;
        // Клетка отрывается целиком, крошится до пылинки и гаснет
        const size = f < .16 ? bp : f < .5 ? 2 : 1;
        const x = x0[i] + push[i] * Math.pow(age, 1.9) | 0;
        const y = y0[i] + (rise[i] + Math.sin(phase[i] + age * 6) * sway[i]) * age | 0;
        if (x < 0 || y < 0 || x + size > DW || y + size > DH) continue;
        const a = f < .4 ? 255 : 255 * Math.pow(1 - (f - .4) / .6, 1.5) | 0;
        const w = f < .55 ? f / .55 : 1, c0 = own[i], c1 = ash[i];
        const r = (c0 & 255) + ((c1 & 255) - (c0 & 255)) * w, g = (c0 >> 8 & 255) + ((c1 >> 8 & 255) - (c0 >> 8 & 255)) * w, b = (c0 >> 16) + ((c1 >> 16) - (c0 >> 16)) * w;
        const v = (a << 24) | (b << 16) | (g << 8) | r;
        for (let o = y * DW + x, row = 0; row < size; row++, o += DW) for (let col = 0; col < size; col++) buf[o + col] = v;
      }
      dctx.putImageData(image, 0, 0);
    };
    const frame = now => {
      t = clamp(t + dir * clamp((now - last) / 1000, 0, .1), 0, end);
      last = now;
      paint();
      if (dir > 0 ? t < end : t > 0) { raf = requestAnimationFrame(frame); return; }
      raf = 0;
      layer.remove();
      if (dir < 0) { photo.style.visibility = ''; if (light) light.style.opacity = ''; }
      const done = onEnd;
      onEnd = null;
      if (done) done(dir > 0);
    };
    return {
      run(d, done) {
        dir = d; onEnd = done;
        getComputedStyle(back).opacity;                             // начальная прозрачность фона применена: переход пойдёт
        // Фон гаснет вместе со сменой цветов страницы, а проявляется уже после неё: на ещё светлой
        // странице тёмный фон снимка проступил бы трафаретом фигуры
        back.style.transition = d > 0 ? 'opacity .36s ease' : 'opacity .45s ease .32s';
        back.style.opacity = d > 0 ? 0 : 1;
        if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
      }
    };
  }

  /* Портрет и тема. Первое включение светлой темы убирает портрет так же, как клик по нему: снимок
     рассыпается, текст переезжает в центр, и в этот момент страница начинает светлеть. Портрет до
     перезагрузки не вернётся, текст остаётся в центре, и дальше тема переключается сразу */
  const face = { gone: false };                                    // gone: портрет рассыпан и до перезагрузки не вернётся
  // Точка, от которой портрет рассыпается при смене темы: лицо
  const faceAt = () => [portrait.offsetWidth * .5, portrait.offsetHeight * .34];
  // Распад для тумблера считается заранее, чтобы само переключение не подтормаживало
  function prepFace() {
    if (calm || face.gone || !portrait) return;
    const shot = bake();
    if (shot) plan(shot, ...faceAt());
  }

  // Пока портрет рассыпается, тема ждёт переезда текста. Если за это время тумблер нажали ещё раз,
  // применится последний выбор
  let themeNext = null;
  function themeHero(light, apply) {
    if (themeNext) { themeNext = apply; return; }
    if (face.gone || !light || !portrait || !hero || !heroCopy) { apply(); return; }
    face.gone = true;
    const hit = $('#portrait-hit');
    if (hit) hit.remove();
    const done = () => { portrait.hidden = true; };
    const img = $('#photo img'), r = portrait.getBoundingClientRect();
    // Первый экран за краем окна или «уменьшить движение»: всё меняется сразу, без эффектов
    const seen = !calm && !!heroCopy.animate && r.bottom > 0 && r.top < innerHeight;
    const fx = seen && img && img.complete && img.naturalWidth ? makeDust(...faceAt(), 'shown') : null;
    if (!fx) { done(); solo(); apply(); return; }
    fx.run(1, done);
    themeNext = apply;
    setTimeout(() => {
      settle(0);
      const go = themeNext;
      themeNext = null;
      go();
    }, DUST.spread * DUST.shiftAt * 1000);
  }

  function initDust() {
    const hit = $('#portrait-hit'), img = $('#photo img');
    if (!hit || !img || !hero || !portrait || !heroCopy) return;
    // Пока идут вступительные анимации первого экрана, клик не принимаем
    let ready = calm;
    // Клик принимаем после входной анимации первого экрана или сразу после сборки (js/intro.js)
    if (window.Intro && window.Intro.running) window.Intro.onDone(() => { ready = true; });
    else setTimeout(() => { ready = true; }, document.documentElement.classList.contains('no-entrance') ? 0 : 2100);
    if (!calm) {
      // Снимок готовим заранее: под курсором в свободную минуту, под пальцем сразу
      const idle = window.requestIdleCallback ? f => requestIdleCallback(f, { timeout: 500 }) : f => setTimeout(f, 60);
      hit.addEventListener('pointerenter', () => idle(bake));
      hit.addEventListener('pointerdown', () => { bake(); });
    }

    hit.addEventListener('click', e => {
      if (!ready || face.gone || !img.complete || !img.naturalWidth) return;
      hit.remove();                                                 // эффект одноразовый
      face.gone = true;
      const done = () => { portrait.hidden = true; };
      const r = portrait.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width * portrait.offsetWidth, y = (e.clientY - r.top) / r.height * portrait.offsetHeight;
      const moves = !calm && heroCopy.animate;
      const fx = moves ? makeDust(x, y, 'shown') : null;
      if (fx) { fx.run(1, done); settle(DUST.spread * DUST.shiftAt * 1000); return; }

      // Уменьшенное движение или canvas недоступен: портрет мягко гаснет
      if (portrait.animate) {
        portrait.animate([{ opacity: getComputedStyle(portrait).opacity }, { opacity: 0 }], { duration: 480, easing: 'ease', fill: 'forwards' }).finished.then(done);
      } else done();
      if (moves) { settle(240); return; }
      // Без движения: текст гаснет, раскладка меняется, текст проявляется уже по центру
      if (heroCopy.animate) heroCopy.animate([{ opacity: 1 }, { opacity: 0, offset: .35 }, { opacity: 0, offset: .5 }, { opacity: 1 }], { duration: 640, easing: 'ease' });
      setTimeout(solo, heroCopy.animate ? 270 : 0);
    });
  }

  /* ---------- Тема ---------- */

  /* Тумблер слева в шапке. Сайт всегда открывается в тёмной теме: выбор не запоминается и не берётся
     из настроек системы. Цвета плавно меняют переменные в CSS (@property, ~0,36 с); браузеру без них
     на время смены включаются переходы самих цветов. Сборку первого экрана переключение завершает сразу */
  function initTheme() {
    const btn = $('#theme');
    if (!btn) return;
    const root = document.documentElement, meta = $('meta[name="theme-color"]');
    const smooth = !!(window.CSS && CSS.registerProperty);
    let fading = 0;
    if (!calm) {
      // Распад портрета готовим заранее: в свободную минуту после загрузки (и сборки первого экрана),
      // а если не успели — под курсором или пальцем на тумблере
      const idle = window.requestIdleCallback ? f => requestIdleCallback(f, { timeout: 2000 }) : f => setTimeout(f, 60);
      const later = () => setTimeout(() => idle(prepFace), 1200);
      if (window.Intro && window.Intro.running) window.Intro.onDone(later); else later();
      btn.addEventListener('pointerenter', () => idle(prepFace));
      btn.addEventListener('pointerdown', prepFace);
    }
    // Цвета страницы; сам тумблер переключается сразу по aria-checked, а цвета — когда велит themeHero
    const apply = light => () => {
      if (!smooth && !calm) {
        root.classList.add('theme-fade');
        clearTimeout(fading);
        fading = setTimeout(() => root.classList.remove('theme-fade'), 420);
      }
      root.dataset.theme = light ? 'light' : 'dark';
      if (meta) meta.content = light ? '#F2F1ED' : '#0A0A0B';
    };
    btn.addEventListener('click', () => {
      if (window.Intro && window.Intro.running) window.Intro.finish();
      const light = btn.getAttribute('aria-checked') !== 'false';
      btn.setAttribute('aria-checked', String(!light));
      themeHero(light, apply(light));
    });
  }

  /* ---------- Запуск ---------- */

  renderCards();
  watch(document);
  initLight();
  initDust();
  initTheme();
  $('#year').textContent = new Date().getFullYear();

  addEventListener('scroll', queue, { passive: true });
  addEventListener('resize', queue);
  onScroll();

  grid && grid.addEventListener('click', e => {
    const card = e.target.closest('.card[data-slug]');
    if (card) { originCard = card; viaClick = true; }
  });
  $('#case-close').addEventListener('click', requestClose);
  $('#case-back').addEventListener('click', requestClose);
  addEventListener('keydown', e => { if (e.key === 'Escape' && opened) requestClose(); });
  addEventListener('hashchange', route);
  route();

  /* ---------- Смена языка ---------- */

  // Карточки, открытый кейс и абзац «Обо мне» собираются заново. Видимые блоки меняются
  // через короткое затухание, остальное сразу. Уже показанные блоки не прячутся повторно
  if (I18N) I18N.onChange((lang, info) => {
    if (grid) I18N.fadeBlock(grid, () => {
      renderCards();
      $$('.rv', grid).forEach(el => el.classList.add('is-in'));
      bindCards();
    }, info);
    if (lead) I18N.fadeBlock(lead, () => { splitLead(); onScroll(); }, info);
    if (opened) {
      const c = CASES.find(x => x.slug === opened);
      if (c) I18N.fadeBlock(caseBody, () => {
        caseBody.innerHTML = renderCase(c);
        $$('.rv, .rv-line', caseBody).forEach(el => el.classList.add('is-in'));
      }, info);
      document.title = T('case.docTitle', loc(c).title);
    }
  });
})();
