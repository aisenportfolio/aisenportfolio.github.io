/* Языки сайта: словари RU/EN и переключение.
   Единственный источник состояния языка — I18N.lang. Тексты страницы помечены data-i18n="ключ",
   атрибуты — data-i18n-attr="атрибут:ключ; атрибут:ключ". Кейсы переводятся в js/data.js (CASES_EN).
   Выбор языка хранится в localStorage («lang»); его читает скрипт в <head> ещё до первого показа текста. */
(() => {
  'use strict';

  const DICT = {
    ru: {
      'meta.title': 'Аслан — веб-разработчик. Сайты и веб-приложения для бизнеса',
      'meta.description': 'Разрабатываю сайты и веб-приложения для бизнеса: от структуры и дизайна до запуска и поддержки.',
      'skip': 'К работам',
      'nav.label': 'Разделы сайта',
      'nav.works': 'Работы',
      'nav.about': 'Обо мне',
      'nav.contacts': 'Контакты',
      'lang.label': 'Язык сайта',
      'lang.ru': 'Русский',
      'lang.en': 'English',
      'theme.label': 'Тёмная тема',
      'theme.title': 'Светлая или тёмная тема',

      'hero.who': 'Аслан, веб-разработчик',
      // Заголовок по строкам; «|» — дополнительный перенос только на узком экране.
      // Неразрывный пробел ( ) держит пары слов вместе
      'hero.title': ['Создаю|сайты', 'под ваш|бизнес'],
      'hero.lead': 'Разрабатываю сайты и веб-приложения: от структуры и дизайна до запуска и поддержки.',
      'hero.tg': 'Написать в Telegram',
      'hero.works': 'Смотреть работы',
      'hero.photo': 'Аслан, портрет на тёмном фоне',

      'works.title': 'Работы',
      'works.noscript': 'Список работ загружается скриптом. Напишите мне в Telegram, пришлю ссылки на проекты.',
      'card.more': 'Смотреть кейс',
      'card.next': 'Следующий проект',
      'card.ask': 'Есть задача? Расскажите, что нужно сделать',

      'about.title': 'Обо мне',
      'about.lead': 'Разрабатываю сайты и веб-приложения для бизнеса. Продумываю структуру, собираю интерфейсы, подключаю необходимые функции и довожу проект до запуска. Использую ИИ-инструменты в разработке и проверяю результат на компьютере и телефоне. Работаю удалённо.',
      'about.f1t': 'Формат', 'about.f1': 'Удалённо',
      'about.f2t': 'Опыт', 'about.f2': 'Больше года в разработке сайтов',
      'about.f3t': 'Чем занимаюсь', 'about.f3': 'Сайты и веб-приложения для бизнеса',

      'skills.title1': 'Навыки', 'skills.title2': 'и инструменты',
      'skills.s1t': 'Разработка сайтов и веб-приложений', 'skills.s1': 'От структуры и интерфейса до рабочих функций.',
      'skills.s2t': 'Адаптивная вёрстка', 'skills.s2': 'Сайт одинаково удобен на компьютере, планшете и телефоне.',
      'skills.s3t': 'Проектирование пользовательских сценариев', 'skills.s3': 'Путь от первого экрана до заявки без лишних шагов.',
      'skills.s4t': 'Анимации и интерактив', 'skills.s4': 'Движение при прокрутке и отклик интерфейса на действия.',
      'skills.s5t': 'Интеграции', 'skills.s5': 'Формы заявок, переход в мессенджер с готовым сообщением.',
      'skills.s6t': 'Запуск и поддержка', 'skills.s6': 'Хостинг, свой домен, правки и развитие после запуска.',
      'tech.title': 'Технологии',
      'tech.t1': 'Вёрстка и интерфейс',
      'tech.t2': 'Веб-приложения',
      'tech.t3': 'Серверная часть',
      'tech.t4': 'Скрипты и автоматизация',
      'tech.t5': 'Хостинг',
      'ai.title': 'ИИ-инструменты',
      'ai.note': 'Помогают в разработке, результат проверяю сам',

      'process.title1': 'Подход', 'process.title2': 'к работе',
      'process.p1t': 'Разбор задачи', 'process.p1': 'Выясняю, что есть сейчас, кому это нужно и что мешает. На выходе список: что оставить, что убрать, что добавить.',
      'process.p2t': 'Проектирование', 'process.p2': 'Собираю структуру и путь пользователя: какие экраны нужны и как дойти до цели за минимум шагов.',
      'process.p3t': 'Разработка', 'process.p3': 'Собираю интерфейс и функции, использую ИИ-инструменты и проверяю результат на компьютере и телефоне.',
      'process.p4t': 'Запуск и поддержка', 'process.p4': 'Публикую сайт, подключаю домен и остаюсь на связи: правки и развитие после запуска.',

      'contacts.title': 'Контакты',
      'contacts.note': 'Напишите, что нужно сделать. Удобнее всего в Telegram.',
      'contacts.wa': 'Написать в чат',
      'contacts.waLabel': 'WhatsApp: написать в чат',
      'footer.name': 'Аслан',

      'case.back': 'Все работы',
      'case.close': 'Закрыть кейс',
      'case.role': 'Роль', 'case.year': 'Год', 'case.site': 'Сайт',
      'case.open': 'Открыть сайт',
      'case.numbers': 'Результат в цифрах',
      'case.problem': 'Проблема', 'case.solution': 'Решение',
      'case.merge': 'Было и стало',
      'case.before': n => `Было: ${n} ${plural(n, 'ресурс', 'ресурса', 'ресурсов')}`,
      'case.after': 'Стало: одна точка входа',
      'case.removed': 'Что убрано', 'case.added': 'Что добавлено', 'case.easier': 'Что стало удобнее клиентам',
      'case.shots': 'Экраны проекта', 'case.shotsLabel': 'Экраны',
      'case.myRole': 'Моя роль', 'case.stack': 'Стек', 'case.tools': 'Инструменты',
      'case.end': 'Есть похожая задача? Напишите, разберём.',
      'case.docTitle': name => `${name}: кейс. Аслан`,

      'intro.skip': 'Пропустить'
    },

    en: {
      'meta.title': 'Aslan — web developer. Websites and web apps for business',
      'meta.description': 'I build websites and web apps for business, from structure and design to launch and ongoing support.',
      'skip': 'Skip to work',
      'nav.label': 'Site sections',
      'nav.works': 'Work',
      'nav.about': 'About',
      'nav.contacts': 'Contact',
      'lang.label': 'Site language',
      'lang.ru': 'Русский',
      'lang.en': 'English',
      'theme.label': 'Dark theme',
      'theme.title': 'Light or dark theme',

      'hero.who': 'Aslan, web developer',
      'hero.title': ['I\u00a0build|websites', 'for\u00a0your|business'],
      'hero.lead': 'I build websites and web apps, from structure and design to launch and ongoing support.',
      'hero.tg': 'Message on Telegram',
      'hero.works': 'View work',
      'hero.photo': 'Aslan, portrait on a dark background',

      'works.title': 'Work',
      'works.noscript': 'The project list needs JavaScript. Message me on Telegram and I will send links to the projects.',
      'card.more': 'View case',
      'card.next': 'Next project',
      'card.ask': 'Have a task? Tell me what you need',

      'about.title': 'About',
      'about.lead': 'I build websites and web apps for business. I plan the structure, build the interfaces, add the features the project needs and take it all the way to launch. I use AI tools in development and check the result on desktop and phone. I work remotely.',
      'about.f1t': 'Format', 'about.f1': 'Remote',
      'about.f2t': 'Experience', 'about.f2': 'Over a year building websites',
      'about.f3t': 'What I do', 'about.f3': 'Websites and web apps for business',

      'skills.title1': 'Skills', 'skills.title2': 'and tools',
      'skills.s1t': 'Website and web app development', 'skills.s1': 'From structure and interface to working features.',
      'skills.s2t': 'Responsive layout', 'skills.s2': 'Equally easy to use on desktop, tablet and phone.',
      'skills.s3t': 'User flow design', 'skills.s3': 'From the first screen to a request without extra steps.',
      'skills.s4t': 'Animation and interaction', 'skills.s4': 'Motion on scroll and an interface that responds to actions.',
      'skills.s5t': 'Integrations', 'skills.s5': 'Request forms, hand-off to a messenger with a ready message.',
      'skills.s6t': 'Launch and support', 'skills.s6': 'Hosting, your own domain, changes and growth after launch.',
      'tech.title': 'Technologies',
      'tech.t1': 'Layout and interface',
      'tech.t2': 'Web apps',
      'tech.t3': 'Back end',
      'tech.t4': 'Scripts and automation',
      'tech.t5': 'Hosting',
      'ai.title': 'AI tools',
      'ai.note': 'They help with development; I check the result myself',

      'process.title1': 'How', 'process.title2': 'I work',
      'process.p1t': 'Understanding the task', 'process.p1': 'I find out what exists now, who it is for and what gets in the way. The result is a list: what to keep, what to remove, what to add.',
      'process.p2t': 'Design', 'process.p2': 'I plan the structure and the user path: which screens are needed and how to reach the goal in as few steps as possible.',
      'process.p3t': 'Development', 'process.p3': 'I build the interface and features, use AI tools and check the result on desktop and phone.',
      'process.p4t': 'Launch and support', 'process.p4': 'I publish the site, connect the domain and stay in touch for changes and growth after launch.',

      'contacts.title': 'Contact',
      'contacts.note': 'Tell me what you need. Telegram is the easiest way to reach me.',
      'contacts.wa': 'Open chat',
      'contacts.waLabel': 'WhatsApp: open chat',
      'footer.name': 'Aslan',

      'case.back': 'All work',
      'case.close': 'Close case',
      'case.role': 'Role', 'case.year': 'Year', 'case.site': 'Site',
      'case.open': 'Open site',
      'case.numbers': 'Results in numbers',
      'case.problem': 'Problem', 'case.solution': 'Solution',
      'case.merge': 'Before and after',
      'case.before': n => `Before: ${n} ${n === 1 ? 'resource' : 'resources'}`,
      'case.after': 'After: one entry point',
      'case.removed': 'What was removed', 'case.added': 'What was added', 'case.easier': 'What got easier for customers',
      'case.shots': 'Project screens', 'case.shotsLabel': 'Screens',
      'case.myRole': 'My role', 'case.stack': 'Stack', 'case.tools': 'Tools',
      'case.end': 'Have a similar task? Message me and we will work it out.',
      'case.docTitle': name => `${name}: case. Aslan`,

      'intro.skip': 'Skip'
    }
  };

  function plural(n, one, few, many) {
    const a = n % 10, b = n % 100;
    return a === 1 && b !== 11 ? one : a >= 2 && a <= 4 && (b < 12 || b > 14) ? few : many;
  }

  const root = document.documentElement;
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let lang = root.lang === 'en' ? 'en' : 'ru';
  const listeners = [];

  function t(key, ...args) {
    const v = (DICT[lang] && key in DICT[lang]) ? DICT[lang][key] : DICT.ru[key];
    return typeof v === 'function' ? v(...args) : v;
  }

  /* ---------- Перемешивание символов при смене языка ---------- */

  // Набор символов для перемешивания: буквы обоих алфавитов, без экзотики
  const POOL = 'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЭЮЯабвгдежзиклмнопрстуфхцчшэюяABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  const rnd = n => { let s = ''; for (let i = 0; i < n; i++) s += POOL[Math.random() * POOL.length | 0]; return s; };

  let token = 0;            // номер текущего перехода: более новый отменяет старый
  const pending = new Map(); // элемент → функция, ставящая конечный текст

  const visible = el => {
    const r = el.getBoundingClientRect();
    return r.bottom > 0 && r.top < innerHeight && r.width > 0 && r.height > 0;
  };

  function settleAll() {
    pending.forEach(done => done());
    pending.clear();
  }

  // Короткий текст: 3 стадии случайных символов, затем правильная строка. Всего ~300 мс.
  // Скринридер читает только правильную строку, перемешанная часть скрыта от него
  function scramble(el, text, my) {
    const from = el.textContent.length;
    const done = () => { el.textContent = text; el.removeAttribute('data-scrambling'); };
    pending.set(el, done);
    el.setAttribute('data-scrambling', '');
    const stages = [0, 70, 140, 210];
    stages.forEach((ms, i) => setTimeout(() => {
      if (my !== token || !pending.has(el)) return;
      const n = Math.round(from + (text.length - from) * ((i + 1) / stages.length));
      // Пробелы оставляем на местах, чтобы строка не прыгала по ширине
      let s = '';
      for (let j = 0; j < n; j++) s += text[j] === ' ' ? ' ' : (j < Math.floor(text.length * i / stages.length) ? text[j] || rnd(1) : rnd(1));
      el.innerHTML = '';
      const sr = document.createElement('span'); sr.className = 'sr-only'; sr.textContent = text;
      const vis = document.createElement('span'); vis.setAttribute('aria-hidden', 'true'); vis.textContent = s;
      el.append(sr, vis);
    }, ms));
    setTimeout(() => { if (my === token && pending.has(el)) { done(); pending.delete(el); } }, 290);
  }

  // Длинный текст: быстрое спокойное затухание и появление, ~300 мс
  // Текст меняется по таймеру, а не по окончанию анимации: в фоновой вкладке анимации стоят,
  // а содержимое всё равно должно смениться
  function fade(el, apply, my) {
    let a = null;
    const done = () => { if (a) a.cancel(); apply(); };
    pending.set(el, done);
    a = el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 120, easing: 'ease-in', fill: 'forwards' });
    setTimeout(() => {
      if (my !== token || !pending.has(el)) return;
      pending.delete(el);
      done();
      el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 170, easing: 'ease-out' });
    }, 120);
  }

  // Меняет текст элемента с учётом видимости и длины
  function swap(el, text, my, animate) {
    if (el.textContent === text) return;
    if (!animate || !visible(el)) { el.textContent = text; return; }
    if (text.length > 48 || el.textContent.length > 48) fade(el, () => { el.textContent = text; }, my);
    else scramble(el, text, my);
  }

  /* ---------- Применение языка ---------- */

  function applyStatic(my, animate) {
    document.querySelectorAll('[data-i18n]').forEach(el => swap(el, t(el.dataset.i18n), my, animate));
    document.querySelectorAll('[data-i18n-attr]').forEach(el => {
      el.dataset.i18nAttr.split(';').forEach(pair => {
        const [attr, key] = pair.split(':').map(s => s.trim());
        if (attr && key) el.setAttribute(attr, t(key));
      });
    });
    document.title = t('meta.title');
    const desc = document.querySelector('meta[name="description"]');
    if (desc) desc.setAttribute('content', t('meta.description'));
    document.querySelectorAll('[data-lang-btn]').forEach(b => {
      const on = b.dataset.langBtn === lang;
      b.setAttribute('aria-pressed', String(on));
    });
  }

  // Заголовок первого экрана: слова в масках .ln. Строки разделяет <br>, «|» внутри строки — <br class="br-m">,
  // перенос только на узком экране
  function renderTitle(el) {
    const word = w => `<span class="ln"><span>${w.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</span></span>`;
    el.innerHTML = t('hero.title')
      .map(line => line.split('|').map(part => part.split(' ').map(word).join(' ')).join(' <br class="br-m">'))
      .join(' <br>');
  }

  function set(next, opts = {}) {
    next = next === 'en' ? 'en' : 'ru';
    // Сначала завершаем сборку первого экрана, затем меняем язык
    if (window.Intro && window.Intro.running) window.Intro.finish();
    if (window.Scenes && window.Scenes.releaseAll && next !== lang) window.Scenes.releaseAll();
    const my = ++token;
    settleAll();
    const animate = opts.animate !== false && !calm;
    const changed = next !== lang;
    lang = next;
    root.lang = lang;
    try { localStorage.setItem('lang', lang); } catch (e) { /* хранилище недоступно: работаем без него */ }
    applyStatic(my, animate && changed);

    const title = document.getElementById('hero-title');
    if (title) {
      const wasVisible = visible(title);
      renderTitle(title);
      if (animate && changed && wasVisible) title.querySelectorAll('.ln > span').forEach(w => {
        const text = w.textContent; w.textContent = ''; w.textContent = text; scramble(w, text, my);
      });
    }
    listeners.forEach(f => f(lang, { animate: animate && changed, token: my, isCurrent: () => my === token }));
  }

  window.I18N = {
    get lang() { return lang; },
    t, set, plural,
    onChange(f) { listeners.push(f); },
    // Плавная смена произвольного блока (карточки, кейс): затухание → новое содержимое → появление
    fadeBlock(el, apply, info) {
      if (!info || !info.animate || !visible(el)) { apply(); return; }
      fade(el, apply, info.token);
    }
  };

  // Первая отрисовка: применяем сохранённый язык без анимации и снимаем скрытие страницы
  set(lang, { animate: false });
  root.classList.remove('i18n-wait');

  document.addEventListener('click', e => {
    const b = e.target.closest('[data-lang-btn]');
    if (b) set(b.dataset.langBtn);
  });
})();
