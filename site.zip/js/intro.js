/* Сборка первого экрана: четыре виртуальных курсора (на телефоне два) одновременно собирают настоящие
   элементы страницы, как команда в Figma. Сцена описана на общем наборе действий js/kit.js:
   все времена от одного старта, все точки — от фактических размеров элементов.

     0,15–1,7 с курсор «перенос» ставит портрет, тянет его угол до размера и выравнивает по направляющей;
     0,25–1,6 с курсор «текст» создаёт текстовое поле и набирает заголовок очередями знаков;
     0,6–1,1 с  курсор «картинки и кнопки» ставит подпись над заголовком;
     1,2–2,5 с  описание: поле, строки, выравнивание; главная кнопка ставится, вторая растягивается;
     2,5–3,4 с  общее выделение, щелчок мимо — выделение снято, курсоры уходят.
   На телефоне (≈2,8 с) курсоров два: «перенос» ставит портрет и главную кнопку, «текст» набирает заголовок,
   затем создаёт поле описания и проявляет его строки; подпись и вторая кнопка встают на место сами.
   Каждый элемент появляется в момент своего действия, итоговая раскладка не меняется.
   Любой способ завершения ведёт в finish(): анимации снимаются, временные слои удаляются,
   и страница остаётся в обычном статичном виде.

   Когда запускается: решает скрипт в <head> (класс html.intro) — один раз за сессию вкладки,
   без якоря в адресе, без prefers-reduced-motion. Повторный показ для проверки: ?intro=1
   Сцена ждёт шрифты и портрет (не дольше 0,9 с), а если вкладка открыта в фоне — пока её не покажут.
   Прерывают сцену клавиша, щелчок или касание без прокрутки, колесо мыши, прокрутка дальше 120 px,
   смена ширины окна. Смена одной высоты (адресная строка телефона, встроенный браузер Telegram
   разворачивается) сцену не прерывает: она пересобирается по новым размерам с того же момента */
(() => {
  'use strict';

  const root = document.documentElement;
  const timers = [], doneCbs = [], offs = [];
  let state = 'idle';            // idle → waiting → running → done
  let stage = null, skipBtn = null, build = null, t0 = 0;

  const Intro = window.Intro = {
    get running() { return state === 'waiting' || state === 'running'; },
    finish,
    onDone(f) { if (Intro.running) doneCbs.push(f); else f(); }
  };

  if (!root.classList.contains('intro')) return;
  window.__introStarted = true;
  state = 'waiting';
  try { sessionStorage.setItem('introSeen', '1'); } catch (e) { /* без хранилища интро просто покажется снова */ }

  /* ---------- Завершение ---------- */

  function finish() {
    if (state === 'done' || state === 'idle') return;
    state = 'done';
    timers.splice(0).forEach(clearTimeout);
    offs.splice(0).forEach(off => off());
    if (stage) { stage.cancel(); stage = null; }
    if (skipBtn) { skipBtn.remove(); skipBtn = null; }
    root.classList.remove('intro', 'intro-run');
    root.classList.add('no-entrance');
    doneCbs.splice(0).forEach(f => { try { f(); } catch (e) { /* чужая ошибка не мешает остальным */ } });
  }

  // Действия посетителя завершают сцену сразу; само действие (клик, прокрутка, переход) выполняется как обычно
  const on = (target, type, opts, test) => {
    const h = e => { if (!test || test(e)) finish(); };
    target.addEventListener(type, h, opts);
    offs.push(() => target.removeEventListener(type, h, opts));
  };
  const passive = { capture: true, passive: true };
  on(window, 'keydown', true);
  // Мышь — сразу по нажатию. Палец — только касанием без прокрутки (click): прокрутка начинается с того же касания
  on(window, 'pointerdown', passive, e => e.pointerType !== 'touch');
  on(window, 'click', true);
  on(window, 'wheel', passive);
  // Небольшая прокрутка пальцем сцену не прерывает: слои сцены лежат в первом экране и едут вместе с ним
  on(window, 'scroll', passive, () => scrollY > 120);
  on(window, 'hashchange', passive);
  let lastW = innerWidth, resizeTimer = 0;
  on(window, 'resize', passive, () => {
    if (Math.abs(innerWidth - lastW) > 1) return true;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(rebuild, 120);
    return false;
  });

  /* ---------- Старт ---------- */

  // Ждём шрифты и портрет не дольше 900 мс: от шрифтов зависят размеры заголовка, по которым идут курсоры,
  // а пустую рамку вместо портрета ставить незачем
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const fonts = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
  const img = document.querySelector('#photo img');
  const photo = img && !img.complete
    ? new Promise(r => { img.addEventListener('load', r, { once: true }); img.addEventListener('error', r, { once: true }); })
    : Promise.resolve();
  Promise.race([Promise.all([fonts, photo]), wait(900)]).then(() => {
    if (state !== 'waiting') return;
    // Вкладка открыта в фоне: сцену покажем, когда посетитель на неё перейдёт
    if (document.hidden) {
      const go = () => { if (document.hidden) return; document.removeEventListener('visibilitychange', go); begin(); };
      document.addEventListener('visibilitychange', go);
      offs.push(() => document.removeEventListener('visibilitychange', go));
      return;
    }
    begin();
  });

  function begin() {
    if (state !== 'waiting') return;
    if (scrollY > 2 || !window.Kit || !window.Kit.ok) { finish(); return; }
    try { run(); } catch (e) { if (window.Kit && window.Kit.dev) console.warn('intro', e); finish(); }
  }

  // Высота окна изменилась: сцена строится заново по новым размерам и продолжается с того же момента
  function rebuild() {
    if (state !== 'running' || !stage || !build) return;
    const ms = (performance.now() - t0) / stage.tempo;
    try {
      stage.cancel();
      stage = build();
      stage.commit();
      stage.jump(ms);
    } catch (e) { finish(); }
  }

  /* ---------- Сценарий ---------- */

  function run() {
    const Kit = window.Kit, { DRAG, SNAP } = Kit;
    const hero = document.getElementById('top');
    const portrait = document.getElementById('portrait');
    const title = document.getElementById('hero-title');
    const who = hero && hero.querySelector('.hero__who');
    const lead = hero && hero.querySelector('.hero__lead');
    const row = hero && hero.querySelector('.hero__row');
    const b1 = row && row.querySelector('.btn:not(.btn--ghost)'), b2 = row && row.querySelector('.btn--ghost');
    if (!portrait || !title || !who || !lead || !b1 || !b2) { finish(); return; }

    state = 'running';
    const narrow = innerWidth < 900;
    const k = narrow ? .6 : 1;                       // на телефоне сдвиги меньше

    build = () => {
      const s = Kit.stage(hero, { tempo: (narrow ? .9 : 1) * Kit.slow, cursors: narrow ? 2 : 4 });
      // Порядок важен: на телефоне в лимит попадают только первые два
      const A = s.cursor('move'), B = s.cursor('text'), C = s.cursor('media'), D = s.cursor('size');

      // Мерки по готовой раскладке
      const HW = s.hostRect.width;
      const P = s.rel(portrait), TB = s.rel(title), W = s.rel(who), L = s.rel(lead), R = s.rel(row);
      const left = TB.x;                                // левая кромка колонки текста
      const copy = { x: left, y: W.y, w: Math.max(TB.w, L.w, R.w, W.w), h: R.y + R.h - W.y };
      // Видимая часть снимка (края растворены маской); на телефоне снимок шире экрана — берём то, что в окне
      // Верх рамки не выше шапки: снимок выше окна, а маркеры должны быть видны
      const fy = Math.max(P.y + P.h * .1, 72);
      let fb = { x: P.x + P.w * .12, y: fy, w: P.w * .76, h: P.y + P.h * .86 - fy };
      if (narrow) {
        const x0 = Math.max(P.x + P.w * .2, 12), x1 = Math.min(P.x + P.w * .8, HW - 12);
        fb = { x: x0, y: Math.max(P.y + P.h * .14, 64), w: x1 - x0, h: P.h * .5 };
      }
      // Кнопка ниже края окна не собирается: сборку за экраном никто не увидит
      const inView = el => el.getBoundingClientRect().bottom < innerHeight - 4;

      /* A. Портрет: перенос на место, растяжение за угол, выравнивание по направляющей.
         Маркер на широком экране слева внизу (к тексту), на телефоне справа внизу; масштаб от противоположного угла */
      const corner = narrow ? [1, 1] : [0, 1], opp = narrow ? [0, 0] : [1, 0];
      s.drag(portrait, { box: fb, origin: opp, frame: 'move', pad: 0, linger: 120, moves: [
        { c: A, grab: [.5, .5], keys: [[150, { x: 84 * k, y: 30 * k, s: .9 }, DRAG], [560, { x: -7 * k, s: .9 }, SNAP], [680, { s: .9 }]] },
        { c: A, grab: corner, keys: [[840, { s: .9 }, DRAG], [1120, { s: 1.014 }, SNAP], [1230, { x: 6 * k }]] },
        { c: A, grab: [.5, .42], keys: [[1400, { x: 6 * k }, SNAP], [1580, { x: -1.5 * k }, SNAP], [1660, {}]] }
      ] });
      const gx = narrow ? HW / 2 : fb.x + fb.w;
      s.guide({ x: gx, y: fb.y, w: 0, h: fb.h }, 1380, 1720, 'move');

      /* B. Заголовок: текстовое поле тянется из угла, текст набирается очередями знаков */
      const tPad = narrow ? 6 : 10;
      const tp = s.setupType(title, '.ln > span', { pad: tPad, minW: TB.w + tPad * 2 });
      if (tp.box0) s.marquee(tp.box0, { c: B, role: 'text', t0: 270, t1: 500, from: [.04, .45], until: 560, handles: false });
      tp.run({ c: B, t0: 560, t1: 1600 });

      /* C. Подпись над заголовком: перенос на место с небольшим перелётом */
      s.drag(who, { c: C, grab: [.3, .5], frame: 'media', keys: [[620, { x: -46 * k, y: -26 * k }, DRAG], [980, { x: 4 * k }, SNAP], [1080, {}]] });

      if (narrow) {
        /* Телефон: «текст» сразу после заголовка создаёт поле описания и проявляет строки,
           «перенос» после портрета ставит главную кнопку */
        s.marquee({ x: L.x - 6, y: L.y - 6, w: L.w + 12, h: L.h + 12 }, { c: B, role: 'text', t0: 1640, t1: 1820, from: [.04, .2], until: 2340 });
        s.lines(lead, { c: B, t0: 1960, t1: 2300, per: 2, role: 'text' });
        B.exit(2400, { x: 40 * k, y: 30 * k });
        // Кнопка во всю ширину экрана: сдвиг в основном по вертикали, чтобы рамка не уходила за край
        if (inView(b1)) s.drag(b1, { c: A, grab: [.32, .5], frame: 'move', keys: [[1860, { x: -10 * k, y: 44 * k }, DRAG], [2200, { x: 2 * k, y: -3 * k }, SNAP], [2290, {}]] });
        // Вторая кнопка встаёт сама, следом за главной (свободного курсора на телефоне нет)
        s.add(b2, [{ opacity: 0, translate: '0 10px' }, { opacity: 1, translate: '0 0' }], { delay: 2240, duration: 320 });
      } else {
        B.exit(1760, { x: 46 * k, y: -34 * k });

        /* D. Описание: поле, строки по группам (абзац стоит чуть правее места), затем A ставит его по левой направляющей */
        const LX = 20 * k;
        if (D.real) s.marquee({ x: L.x + LX - 8, y: L.y - 8, w: L.w + 16, h: L.h + 16 }, { c: D, role: 'size', t0: 1240, t1: 1480, until: 1900 });
        s.lines(lead, { t0: 1460, t1: 1860, per: 1, role: 'size', dx: LX });
        s.drag(lead, { c: A, grab: [.06, .3], frame: 'move', appear: false, keys: [[1960, { x: LX }, DRAG], [2220, { x: -3 * k }, SNAP], [2300, {}]] });
        s.guide({ x: left, y: copy.y - 10, w: 0, h: copy.h + 20 }, 1900, 2380, 'move');

        /* Кнопки: главную C ставит переносом, вторую D растягивает за правый край */
        if (inView(b1)) s.drag(b1, { c: C, grab: [.32, .5], frame: 'media', keys: [[1720, { x: -34 * k, y: 36 * k }, DRAG], [2080, { x: 3 * k, y: -3 * k }, SNAP], [2180, {}]] });
        C.exit(2280);
        if (inView(b2)) s.crop(b2, { c: D, round: '999px', handle: 'r', frame: 'size', pad: 4, keys: [
          [1980, [0, .66, 0, 0], DRAG], [2300, [0, .06, 0, 0], 'linear'], [2360, [0, .06, 0, 0], SNAP], [2460, [0, 0, 0, 0]]
        ] });
        D.exit(2540);
      }

      /* A. Общее выделение, щелчок мимо: выделение снято, курсор уходит */
      const all = { x: copy.x - 14, y: copy.y - 14, w: copy.w + 28, h: copy.h + 28 };
      s.marquee(all, { c: A, role: 'move', t0: 2480, t1: 2800, until: 2960 });
      const away = narrow ? { x: all.x + all.w * .7, y: all.y + all.h + 30 } : { x: all.x + all.w + 70, y: all.y + all.h * .55 };
      A.go(2950, away, 140).press(2950, 3010).exit(3070, { x: 40 * k, y: 36 * k });
      return s;
    };

    stage = build();
    const total = stage.commit();
    t0 = performance.now();
    // Элементы и временные слои взяты анимациями под контроль: снимаем скрывающий класс
    root.classList.add('intro-run');
    root.classList.remove('intro');

    /* «Пропустить»: ненавязчиво внизу справа (на телефоне под шапкой), фокус не перехватывает */
    skipBtn = document.createElement('button');
    skipBtn.type = 'button';
    skipBtn.className = 'intro-skip';
    skipBtn.textContent = window.I18N ? window.I18N.t('intro.skip') : 'Пропустить';
    skipBtn.addEventListener('click', finish);
    document.body.append(skipBtn);
    skipBtn.animate([{ opacity: 0 }, { opacity: 1 }], { delay: 300, duration: 300, fill: 'both' });

    // Отладка: ?intro=1&introdebug=1 — сцена не завершается сама, Intro.seek(мс) показывает кадр в заданный момент
    if (/[?&]introdebug=1/.test(location.search)) {
      offs.splice(0).forEach(off => off());   // в отладке сцену не прерывают ни прокрутка, ни смена размера окна
      Intro.seek = ms => stage && stage.seek(ms);
      const at = /[?&]introseek=(\d+)/.exec(location.search);
      if (at) Intro.seek(+at[1]);
      return;
    }
    // ?step=1: клавиши «.» и «,» листают кадры, поэтому нажатие клавиши сцену не завершает
    if (Kit.stepMode) { offs.splice(0).forEach(off => off()); on(window, 'pointerdown', passive); on(window, 'wheel', passive); return; }
    timers.push(setTimeout(finish, total + 120));
  }
})();
